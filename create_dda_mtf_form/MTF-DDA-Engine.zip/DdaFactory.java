/* Copyright (C) Ascension Logistics - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Author ----  
 *      By Jonathan Nazario 
 *   Email <jnazario@ascensionlogistics.com>
 *    Date March 2017
 */
package com.alx.les.dda;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import org.apache.log4j.Logger;

import org.apache.commons.lang3.StringUtils;
import com.alx.les.dda.DdaFactory.DdaProperties.FormMode;
import com.redprairie.moca.MocaException;
import com.redprairie.moca.MocaResults;
import com.redprairie.moca.NotFoundException;
import com.redprairie.mtf.CMtfUtil;
import com.redprairie.mtf.MtfConstants;
import com.redprairie.mtf.MtfConstants.EFlow;
import com.redprairie.mtf.MtfErrors;
import com.redprairie.mtf.exceptions.XFailedRequest;
import com.redprairie.mtf.exceptions.XFormAlreadyOnStack;
import com.redprairie.mtf.exceptions.XInvalidArg;
import com.redprairie.mtf.exceptions.XMissingObject;
import com.redprairie.mtf.foundation.presentation.AFormLogic;
import com.redprairie.mtf.foundation.presentation.CVirtualKey;
import com.redprairie.mtf.foundation.presentation.CWidgetActionAdapter;
import com.redprairie.mtf.foundation.presentation.ICommand;
import com.redprairie.mtf.foundation.presentation.IContainer;
import com.redprairie.mtf.foundation.presentation.IDisplay;
import com.redprairie.mtf.foundation.presentation.IEntryField;
import com.redprairie.mtf.foundation.presentation.IEntryField.EMtfDataType;
import com.redprairie.mtf.foundation.presentation.IForm;
import com.redprairie.mtf.foundation.presentation.IFormSegment;
import com.redprairie.mtf.foundation.presentation.IInteractiveWidget;
import com.redprairie.mtf.foundation.presentation.IVirtualKey;
import com.redprairie.mtf.foundation.presentation.IWidget;
import com.redprairie.mtf.foundation.presentation.IWidgetActionValidator;
import com.redprairie.mtf.terminal.presentation.AInteractiveWidget;
import com.redprairie.mtf.terminal.presentation.CForm;
import com.redprairie.mtf.terminal.presentation.CTextSelection;


/***
 * IMPORTANT INFORMATION ABOUT:  DdaFactory
 * 
 * This class currently needs refactoring of the inner-classes.
 * 
 * Mainly, the inner-classes defined here are for code structuring
 * and aid other developers navigate through the code. In reality,
 * this is not best practice but there was not other way in the
 * short time this was develop.
 * 
 * Because inner-classes can access parent members, we are just
 * taking advantage of that and skipping developing the correct
 * pipeline to pass information...
 * 
 * To fix this, extract the inner classes into there own class.
 * This will cause the internal references to create errors 
 * through the class.  Just setup appropriate getters/setters,
 * and fix the pipeline of information until errors are resolve.
 * 
 * @author jonathan
 *
 */


/* TASK TO COMPLETE... */

// IMPORTANT ITEMS
// TODO: Support complex commands... - example at LOOKUP_FORM.ListActions()
// TODO: INVESTIGATE WHY NEED TO CLEAR RESULTS - ONFORM-ENTRY - PROPERTIES
// TODO: PROMPT FIELD AND GRID - HANDLE DATA TYPE AND BUILD VALID CLAUSES...
// TODO: FKEY ACTION - SET FOCUS IN CURRENT ITEM AFTER PROCESSING...

// NEW FEATURES
// TODO: RESULTS - PUT SELECTED ITEM IN PREVIOUS INDEX AFTER REPROCESSING..
// TODO: AUTO-FIND -> Go directly to results
// TODO: ACTION: Auto-Default ENTER action when no child dda and only one FK


// TESTING
// TODO: DDA FORM FLOWS - Retest this for modes {CONTINUE,REDO_FIELD OR FORM}
// TODO: UNBIND FKEYS WHEN OVERRIDING
// TODO: INNER CLASSES are mainly organizing code.  Should we load late?
// TODO: Action/Child DDA need to be there own "duplicate" form - because we can't redefine link fields...

// INFORMATION
// -- Default FK == VK_F8 for RF DDA Forms (simple solution)
//    Executed from DdaMode_Results_Ctl_DdaResults :: onFieldExit()
//    Setting this FKey Action means user wants to auto-flow on hitting enter (exit) 

// -- MTF ENGINE Default FK functions (why I use F8 for default)
// Standard Global Function Keys
//public static final IVirtualKey VK_CANCEL = VK_F1;
//public static final IVirtualKey VK_LOOK = VK_F2;
//public static final IVirtualKey VK_NEXTNUM = VK_F3;
//public static final IVirtualKey VK_ACCEPT = VK_F6;
//public static final IVirtualKey VK_TOOL = VK_F7;
//public static final IVirtualKey VK_REFRESH = VK_F9;
//public static final IVirtualKey VK_ASSIST = VK_F10;
//public static final IVirtualKey VK_TRANSLATE = VK_F12;
//
//public static final IVirtualKey VK_SHOWKEYS = VK_GOLD_F3;
//public static final IVirtualKey VK_CLEARFLD = VK_GOLD_F7;
//public static final IVirtualKey VK_ABOUT = VK_GOLD_F10;


// -- FORM FLOW ENUM
//public static enum EFlow {EXECUTE_FORM, SHOW_FORM, CALL_FORM, BACK, RETURN};
//public static enum EUnwindAction {REINIT_FORM, REDO_FIELD_ENTRY, CONTINUE};
//public static enum EXFormAlreadyOnStackReturn {CONTINUE, TRUE, FALSE};


public abstract class DdaFactory extends AFormLogic {

    // Logger utility --------------------------------------
    private static final Logger log = Logger.getLogger(DdaFactory.class);
    
    
    // Static Properties --------------------------------------
    private static final String FrmTypTkn = ":";
    private static final String DdaMstUsage = "M";
    private static final String DdaResultsWidgetName = "ddaresults";

    private static final String RsFld__rfdda_flowto = "rfdda_flowto";
    private static final String RsFld__rfdda_flowstyle = "rfdda_flowstyle";
    
    
	// Instance Variables --------------------------------------
    private FormMode ddaMode;
    private FormFactory ddaFormFactory = new FormFactory();
    private ActionFactory ddaActionFactory = new ActionFactory();

    public IFormSegment segDef;
    public ICommand cmdFkeyBack;
    public IWidgetActionValidator actDdaForm;
    public IWidgetActionValidator actList;
    public DdaResultsWidget resGrid;
    
    private boolean fKeyMcmdExecuted = false;
    private boolean fKeyFlowToNonDda = false;

    // DDA Properties --------------------------------------

    // DDA FORM
    // dda_typ,dda_cmd,auto_find,publish_data_flg
    public String dda_typ = "";
    public String dda_cmd = "";
    public boolean dda_publish_data_flg = false;
    public int dda_auto_find = 0;
    public String grid_prop = "";
    public ActionFactory.ChildDdaAction childDda;
    // list code descriptions where colnam = "auto_find"

    // DDA FIELD
    public List<String> promptFields;          // prompt values from screen..
    public List<String> mcmdFields;	           // what fields will be used by the mcmd execution?
    public List<String> displayFieldsVarNam;   // display field in the DDA Results
    public IEntryField chkfld;
    // var_nam,srtseq
    // ,ena_flg,rqdflg,dflt_flg (prevpage),dspl_only_flg
    // ,fltr_grp,pk_fld_flg,pk_layout_flg
    
    //  --------------------------------------
    

	public abstract ICommand getNewFkeyBackCommand();
	public abstract ICommand getNewFkeyActionCommand(String ddaAction, char fkIdx, String fkCaption
			, List<String> actionFlds);

    
	public DdaFactory(IDisplay _display) throws Exception {
		super(_display);
		
        // Create form and default segment
		String formName = "DdaForm";
		
		frmMain = display.createForm(formName);
		
		// FKey Back will execute RETURN on default.
        frmMain.unbind(frmMain.getCancelCommand());
        cmdFkeyBack = getNewFkeyBackCommand();
        cmdFkeyBack.setVisible(false);
        frmMain.bind(cmdFkeyBack);
        cmdFkeyBack.bind(MtfConstants.VK_FKEY_BACK);

		
		// Engine must use auto layout and accept
        frmMain.setAutoLayout(true);
        frmMain.setAutoAccept(true);
	}

    public void loadDda(String frmName, String usrId) {
		getDdaFormFactory().load(frmName, usrId); 
	}

	public FormMode getDdaFormMode() {
    	return ddaMode;
    }
    private void setDdaFormMode(FormMode mode) {
    	ddaMode = mode;
    }
    private FormFactory getDdaFormFactory() {
    	return ddaFormFactory;
    }
	public ActionFactory getDdaActionFactory() {
		return ddaActionFactory;
	}
	private void setDdaFormActions() {
			actDdaForm = getDdaActionFactory().new FormActions().getFormActions();
	        frmMain.addWidgetAction(actDdaForm);
	}
	
	private AFormLogic getDdaForm(String frmName, EFlow _uTech)
	{
		AFormLogic frm = null;
		try {
			// If form is already loaded use the standard flow...
			if (display.getInstantiatedForm(frmName)!= null) {
				frm = display.createFormLogic(frmName, _uTech);
			}
			// Else create and push to the stack of forms
			else {
				frm = createVirtualDdaForm(frmName, _uTech);
			}
	
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XFormAlreadyOnStack e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return frm;
	}

    public abstract  String getDdaFormClass();
    
	/***
	 * Use this internal function to create "virtual forms"
	 * like the ones needed to flow throw the DDA experience.
	 * For example: a QUERY form needs a RESULTS form.  Similar
	 * when spawning CHILD or ACTION forms internally.
	 * @return 
	 */
	private AFormLogic createVirtualDdaForm(String frmName, EFlow _uTech)
	{
		AFormLogic frmObj = null;
		DdaFormBase frmDda = null;
		String strFormClass = this.getDdaFormClass();
		
	    try {
	        // Similar to the MTF Form creation
	    	// but we need to use the DdaForm class
	    	// which will take care of all bootstrapping.
	    	// Then added to the map of forms.
	        Class frmClass = Class.forName(strFormClass);
	        Constructor dispConstructor = frmClass
	            .getConstructor(new Class[] { IDisplay.class });
	
	        // Load the appropriate widget resource bundle
	        // Every form class will have its own .properties file.
	        display.getWidgetResourceProvider()
	            .setResourceBundle(
	                ResourceBundle.getBundle(strFormClass, Locale
	                    .getDefault()));
	
	        
	        // Create an instance of a class
	        Class<?> clazz = Class.forName(strFormClass);
	        Constructor<?> constructor = clazz.getConstructor(IDisplay.class);
	        frmDda = (DdaFormBase) constructor.newInstance(display);
			frmObj = (AFormLogic) frmDda;
	
	        
	        // Add it to the list of all instantiated forms
	        if (!display.getInstantiatedForms().containsKey(frmName)) {
	            display.getInstantiatedForms().put(frmName, frmObj);                        
	        }   
	    }
	    catch (ClassNotFoundException ex) {
	        log.error("MTF DDA: [" + frmName + "] - No definition for the class with the specified " 
	            + "name [" + strFormClass + "] could be found.", ex);
	    }
	    catch (InvocationTargetException ex) {
	        log.error("MTF DDA: [" + frmName + "] - InvocationTargetException has occurred for "
	            + strFormClass + ". Cause: "
	            + ex.getCause().toString());
	    }
	    catch (IllegalAccessException ex) {
	        log.error("MTF DDA: [" + frmName + "] - IllegalAccessException has occurred for "
	            + strFormClass + ". Cause: "
	            + ex.getCause().toString());
	    }
	    catch (InstantiationException ex) {
	        log.error("MTF DDA: [" + frmName + "] - InstantiationException has occurred for "
	            + strFormClass + ". Cause: "
	            + ex.getCause().toString());
	    }
	    catch (NoSuchMethodException ex) {
	        log.error("MTF DDA: [" + frmName + "] - NoSuchMethodException has occurred for "
	            + strFormClass + ". Cause: "
	            + ex.getCause().toString());
	    }
	    catch (Exception e) {
			e.printStackTrace();
		} 
	
	    frmDda.getForm().setInFlow(_uTech);
	    return frmObj;
	}

	static class DdaProperties {
    	
    	/* PROPERTIES */
    	public enum FormMode { QUERY,RESULTS,ACTION,EXECUTE };

    	/* HELPER FUNCTIONS */
    	public static FormMode convertToFormMode(String sMode) {
    		FormMode mode;
    		if (sMode.equals(FormMode.RESULTS.toString()))
    		{
    			mode = FormMode.RESULTS;
    		}
    		else if (sMode.equals(FormMode.ACTION.toString()))
    		{
    			mode = FormMode.ACTION;
    		}
    		else if (sMode.equals(FormMode.EXECUTE.toString()))
    		{
    			mode = FormMode.EXECUTE;
    		}
    		else
    		{
    			mode = null;
    		}
    		return mode;
    	}
    	
    	public static FormMode getFormModeFromName(String frmName) {
    		FormMode mode = null;
    		
    		if (frmName.contains(FrmTypTkn))
    		{
    			String sDdaMode = "";
                String[] frmSplits = frmName.split("\\"+FrmTypTkn);
                int len = frmSplits.length;
                int modeIdx = len-1;
                
                if (len > 1
                		&& !frmSplits[modeIdx].isEmpty()) 
                {
                	sDdaMode = frmSplits[modeIdx];
                }

                mode = DdaProperties.convertToFormMode(sDdaMode);
    		}
    		
    		return mode;
    	}
    	

    	public static String getFormNameWithoutSuffix(String frmName) {

    		// Extracted name must be the last form name
    		// which is before last string token...
    		// Child and Action forms are prefixed by caller...
    		// ie.  MyForm:ActionForm:Mode
    		
    		String name = frmName;
    		
    		if (frmName.contains(FrmTypTkn))
    		{
                String[] frmSplits = frmName.split("\\"+FrmTypTkn);
                int len = frmSplits.length;
                int frmIdx = len-2;
                
                if (len > 1
                		&& !frmSplits[frmIdx].isEmpty()) 
                {
                	name = frmSplits[frmIdx];
                }
    		}
    		
    		return name;
    	}
    	        
        public static String generateFormName(IForm frm, DdaProperties.FormMode ddaMode)
        {
        	return generateFormName(frm.getIdentifier(),ddaMode);
        }
        public static String generateFormName(String frmName, DdaProperties.FormMode ddaMode)
        {
        	return frmName + FrmTypTkn + ddaMode.toString();
        }   
        
    }
    
    private static class DdaUtils {

    	public static String convertToCSV(List<String> coll) {
    		String dspFldCsv = "";
            if (coll != null && coll.size() > 0)
            {
            	for (String v : coll)
                {
            		dspFldCsv += v + ",";
                }
            	dspFldCsv = dspFldCsv.substring(0,dspFldCsv.length()-1);
            }
            
            return dspFldCsv;
    	}
    	
    	public static List<String> splitCSV(String csvString) {
    		
    		List<String> ls = new LinkedList<String>();
    		
    		// short circuit
    		if (csvString == null || csvString.isEmpty()) {
    			return ls;
    		}
    		
    		// parse and return the list...
    		if (csvString.contains(",")) {
    		
                String[] frmSplits = csvString.split("\\"+",");
                for (String s : frmSplits)
                {
                	ls.add(s);
                }
    		}
    		else {
    			if (csvString != null && !csvString.isEmpty()) {
    				ls.add(csvString);
    			}
    		}
    		
    		return ls;
    	}
    	
    	public static EFlow getEFlow(String _eFlow) {

    		// public static enum EFlow {EXECUTE_FORM, SHOW_FORM, CALL_FORM, BACK, RETURN};
    		
    		EFlow retEFlow = null;
    		String chkVal = _eFlow.toUpperCase();
    		
    		if ("EXECUTE_FORM".equals(chkVal)){
    			retEFlow = EFlow.EXECUTE_FORM;
    		}
    		else if ("SHOW_FORM".equals(chkVal)){
    			retEFlow = EFlow.SHOW_FORM;
    		}
    		else if ("CALL_FORM".equals(chkVal)){
    			retEFlow = EFlow.CALL_FORM;
    		}
    		else if ("BACK".equals(chkVal)){
    			retEFlow = EFlow.BACK;
    		}
    		else if ("RETURN".equals(chkVal)){
    			retEFlow = EFlow.RETURN;
    		}
    		
			return retEFlow;
    	}


    	public static String buildDdaMocaCommand(
    			IDisplay display
    			, String ddaCommand
    			, List<String> mcmdFields
    			, List<String> promptFields)
    	{
    		

            // TODO: Support complex commands...
            // For the moment we only support simple mcmds.
            // If more complex parsing is needed, look at:
            // LOOKUP_FORM.ListActions()

    		
    		// Mcmd clause to build
    		String clause = "";
    		
    		// List of fields to bind...
    		Set<String> flds = new HashSet<String>();
    		if (promptFields != null) flds.addAll(promptFields);
    		if (mcmdFields != null) flds.addAll(mcmdFields);
    		
   		
    		// Reference to forms to process binding against.
    		IForm prevForm = display.getPreviousFormOnStack();
    		IForm curForm = display.getCurrentFormOnStack();
    		

			// Process curForm first, then prevForm
			// looking to bind values to variables...
    		for (int frmIdx = 0; frmIdx < 2; frmIdx++) {
    			
    			// Form switch...
    			IForm frm = (frmIdx==0)
					? curForm : prevForm;

    			// Process fields & widgets...
    			clause += processBindingVariables(flds, frm, DdaResultsWidgetName);			
    			clause += processBindingVariables(flds, frm, null);
    				
    		}
				
			// Clean up "clause" string...
            if (clause != null && !clause.trim().isEmpty()) {
            	clause = clause.substring(0,clause.length()-4);
            }
    		
			String conjOper 
				= clause.isEmpty()
					? ""
					: ddaCommand.toLowerCase().contains(" where ")
						? " and " 
						: " where "
			;
			
			
			return ddaCommand
				+  conjOper
				+  clause;    
    	}

		private static String processBindingVariables(
				Set<String> flds, IForm frm, String widgetName) {
			
			// TODO: IMPORTANT! - SIGNIFICAN IMPROVEMENT - HANDLE DATA TYPE AND BUILD VALID CLAUSES...
			
	    	/* Try binding the fields in the form...
	    	 *  
	    	 * If a widgetName was passed in, we will try to bind
	    	 * only against that widget. (ie. DdaResultsWidgetName -> ship_Id)
	    	 * 
	    	 * Else, binding will occur again the with widget 
	    	 * that has the same field name. (ie. ship_id -> ship_id)
	    	 * 
	    	 */

			String clause = "";

			// TODO: OPTIMIZE! - LOOP IS INNEFFICIENT... QUICK DIRTY...
			log.trace("processBindingVariables trying to bind variables...");
			Iterator<String> it = flds.iterator();
			while (it.hasNext()) {
				String f = it.next();	
				
				IWidget w = null;
				try {
					w = frm.findWidget(
						(widgetName!=null)? widgetName : f 
					);
				} catch (XInvalidArg e) {
					// Muffle... binding failed.
				} catch (XMissingObject e) {
					// Muffle... binding failed.
				}
				
				log.trace("processBindingVariables trying to bind variables f:" + f);
				if (w != null) {
					
					String val = null;
			    	if (w instanceof IEntryField)
			    	{
			    		val = ((IEntryField) w).getText();
			    		log.trace("processBindingVariables trying to bind variables f:" + f + " as EntryField:" + val);
			    	}
			    	else if (w instanceof DdaResultsWidget)
			    	{
			    		DdaResultsWidget drw = (DdaResultsWidget) w;
			    		MocaResults rs = drw.getMocaResults();
			    		int idx = drw.getSelectedIndex()+1;
			    		if (drw.checkDisplayGridTitle() && idx == 1) {
			    		    //When displaying title, should skip the title line.
			    		    idx = 2;
                            if (rs != null && rs.hasNext() && 0 < idx && idx <= rs.getRowCount()) {
                                rs.reset();
                                for (int i=0; i < idx; i++) {
                                    rs.next();
                                }
                            }
			    		}
			    		log.trace("processBindingVariables trying to bind variables f:" + f + " as DdaResultsWidget with idx:" + idx);
			    		if (rs != null) {
			    		    log.trace("processBindingVariables trying to bind variables rs is not null");
			    			// TODO: IMPROVE! - THIS IS NOT EFFICIENT.
			    			// THIS IS WHEN PERFORM FKEY ACTION AND BIND ACT_FIELDS
			    			// BUT IF WE DON'T THEN RS POSITION IS LOST...
			    				
			    			try {
			    				// this errors when result set 
			    				// doesn't have a row selected.
			    				rs.getValue(0);
			    				log.trace("processBindingVariables trying to bind variables rs is not null after getValue(0)");
			    			}
			    			catch (Exception e) {
			    				// we will try safe the binding...
				    			if (rs.hasNext() && 0 < idx && idx <= rs.getRowCount()) {
					    			rs.reset();
					    			for (int i=0; i < idx; i++) {
					    				rs.next();
					    			}	
				    			}	
			    			}

			    			try {
					    		Object o = rs.getValue(f);
					    		if (o != null) {
					    			val = o.toString();
					    		}
					    		log.trace("processBindingVariables trying to bind variables f:" + f + " as DdaResultsWidget with idx:" + idx + ", val:" + val);
			    			}
			    			catch(Exception ex) {
			    				log.warn("MTF DDA: Fail Binding: " + f + " - " + frm.getIdentifier());
			    			}
			    		}
			    	}
			    	else if (w instanceof CDDATextSelection)
			    	{
			    		// TBD - HOW TO IMPLEMENT?...
			    		// FYI - CTextSelection, because DdaResultsWidget is a subclass of it.
			    	}	

					if (val != null && !val.isEmpty())
					{
						String operator 
							= val.contains("%")
								? "like"
								: "=";
						clause += " "
					    + f + " " + operator + " '" + val + "'"
						+ " and ";

						it.remove();
						log.trace("processBindingVariables got clause:" + clause);
					}
				}
			}
			
			return clause;
		}
    }
    
    private class FormFactory {	

    	public void load(String frmName, String usrId) {
    		try {

    			// -- DDA FORM:  Common properties
    			loadDda_FormBase(frmName);
    			FormMode mode = getDdaFormMode();
    			
    			// -- DDA FORM:  Specialized properties
    			switch (mode)
    			{
    			case QUERY:
    			    loadDda_PromptFields(frmName, usrId);
    				break;
    				
    			case RESULTS:
    	    		// Always has results grid
    				resGrid = new DdaResultsWidget(DdaResultsWidgetName,segDef);
    	    		resGrid.setItemLines(grid_prop);    	    		
    	    		
    				loadDda_ChildLink(frmName);
    				loadDda_ActionLinks(frmName);
    			    loadDda_DisplayFields(frmName, usrId);
    				break;

    			case ACTION:
    			    loadDda_PromptFields(frmName, usrId);
    				break;

    			case EXECUTE:
    			    loadDda_PromptFields(frmName, usrId);
    				break;
    			
    			default:
    				// TODO: Improve error
    				throw(new Exception("DdaMode = UNKNOWN"));
    			}
    		} catch (Exception e) {
    			if (e instanceof MocaException)
    			{
    				MocaException ex = (MocaException)e;
    				log.error("MOCA Exception (" + ex.getErrorCode() + ") - "
    		                + ex.getMessage());
    			}

    			e.printStackTrace();
    		}
    	}
    	
    	private void loadDda_FormBase(String frmName) throws XInvalidArg, XFailedRequest, MocaException {
    		
    		frmMain.setIdentifier(frmName);
            segDef = frmMain.createSegment("segDef", false);

            
            // get dda definition from DDA_MST
            String frmNameNoSuffix = DdaProperties.getFormNameWithoutSuffix(frmName);
            MocaResults rs;
    	    rs = session.executeCommand(
    	    	"list dda "
    	        + " where dda_usage = '" + DdaMstUsage + "' "
    	        + "   and dda_id = '" + frmNameNoSuffix + "' "
    	        );
    	    rs.next();
    	    
    	    frmMain.setTitle(rs.getString("mls_text"));
    	    dda_typ = rs.getString("dda_typ");
    	    dda_cmd = rs.getString("dda_cmd");
    	    dda_publish_data_flg = rs.getBoolean("publish_data_flg");
    	    dda_auto_find = rs.getInt("auto_find");
    	    grid_prop = rs.getString("grid_prop");
    	    
    	    
    	    // Set DDA form mode. (default = QUERY)
    	    FormMode mode = DdaProperties.getFormModeFromName(frmName);
    	    
    	    if (mode == null) {
    	    	mode = FormMode.QUERY;
    	    }
    	    if (mode == FormMode.QUERY && dda_auto_find != 0)
    	    {
    	    	mode = FormMode.RESULTS;
    	    }
    	    if (dda_typ.equals("E")) 
    	    {
    	    	mode = FormMode.EXECUTE;
    	    }
    	    
    	    setDdaFormMode(mode);
    	    
    	    
    	    // Set Form Entry/Exit Actions
    		setDdaFormActions();
    	}    	
    	
    	private void loadDda_PromptFields(String frmName, String usrId)
    			throws XFailedRequest {

            String frmNameMain = DdaProperties.getFormNameWithoutSuffix(frmName);

    		MocaResults rsDdaFlds;
    		MocaResults rsVarConfig;
    		try {
    		    rsDdaFlds = session.executeCommand(
    		    	"list gui dda fields by user "
    		        + " where dda_id = '" + frmNameMain + "'"
    		        + "   and dda_fld_typ = 'S'"
    		        + "   and cur_usr_id = '" + usrId + "'"
    		        );
    		    
    		    // get list of fields
    		    String lstFlds = "";
    		    boolean skipComma = true;
    		    while(rsDdaFlds.next())
    		    {
    		    	lstFlds += (skipComma?"":",")
    		    			+ "'" + rsDdaFlds.getString("var_nam") + "'";
    		    	skipComma = false;
    		    }
    		    
    		    // get field type
    		    Map<String,String> lstVarTyp = new HashMap<String,String>();
    		    try {
    		    	rsVarConfig = session.executeCommand(
    		        "get rdt var config "
    		        + " where varlist = [" +lstFlds + "]"
    		        + "   and appl_id = 'dcsrdt'"
    		        + "   and frm_id = '" + frmNameMain + "'"
    		        );

        		    if (rsVarConfig != null)
        		    while (rsVarConfig.next()) {
        		    	lstVarTyp.put(rsVarConfig.getString("var_nam")
        		    			, rsVarConfig.getString("fld_typ"));
        		    }
    		    }
    		    catch (MocaException mex) {
    		    	// muffle...
    		    }
    		    

    		    IEntryField ef = null;
    		    promptFields = new LinkedList<String>();
    		    rsDdaFlds.reset();
    		    while(rsDdaFlds.next())
    		    {
    		        String var_nam = rsDdaFlds.getString("var_nam");   
    		    	if (rsDdaFlds.getBoolean("ena_flg"))
    		    	{
    		    		promptFields.add(var_nam);
    		    	}		    	
    		        ef = segDef.createEntryField(var_nam,var_nam);
    		    	ef.setTag(var_nam);
    		    	((AInteractiveWidget)ef).setTabIndex(rsDdaFlds.getInt("srtseq"));
    		    	ef.setVisible(true);
    		    	ef.setEntryRequired(rsDdaFlds.getBoolean("rqdflg"));
    		    	ef.setEnabled(!rsDdaFlds.getBoolean("dspl_only_flg"));
    		    	
    		    	String fldtyp = lstVarTyp.get(var_nam);
    		    	if (fldtyp != null)
    		    	{
    		    		if (fldtyp.equals("F"))
    		    		{
    		    			ef.setDataType(EMtfDataType.BOOLEAN);
    		    			ef.setLimit(MtfConstants.RF_FLAG_LEN);
    		    			ef.setText("0");
    		    			ef.setRefreshRequired(true);
    		    			ef.refresh();
    		    		}
    		    	}
    		    	
    		    	
    	
    // TODO: HANDLE / SETUP FIELD DATA TYPE?
    // DOES VAR_CONFIG TAKES CARE OF THIS?...
    		    	
//    		        	        	ef.setLimit(30);
//    		        	        	ef.setDataType(EMtfDataType.STRING);
//    		        	        	ef.setDefaultData(false);
//    		//        	        	ef.setAutoTab(true);
    		    	
    		    	
    		    }
    		}
    		catch (MocaException e) {
    		    log.error("MOCA Exception (" + e.getErrorCode() + ") - "
    		        + e.getMessage());
    		}
    	}

    	private void loadDda_DisplayFields(String frmName, String usrId)
    			throws XFailedRequest {

            String frmNameMain = DdaProperties.getFormNameWithoutSuffix(frmName);
            
    		displayFieldsVarNam = new LinkedList<String>();
    		MocaResults rs;
    		try {
    		    rs = session.executeCommand(
    		    	"list gui dda fields by user "
    		        + " where dda_id = '" + frmNameMain + "'"
    		        + "   and dda_fld_typ = 'D'"
    		        + "   and cur_usr_id = '" + usrId + "'"
    		        );

    		    while(rs.next())
    		    {
    		    	if (rs.getBoolean("ena_flg"))
    		    	{
    			        displayFieldsVarNam.add(rs.getString("var_nam"));
    		    	}
    		    }
    		}
    		catch (MocaException e) {
    		    log.error("MOCA Exception (" + e.getErrorCode() + ") - "
    		        + e.getMessage());
    		}	
    	}
    	

    	private void loadDda_ChildLink(String frmName)
    			throws XFailedRequest {

            String frmNameMain = DdaProperties.getFormNameWithoutSuffix(frmName);

    		MocaResults rs;
    		try {
    		    rs = session.executeCommand(
    		    	"get dda child data "
    		        + " where dda_id = '" + frmNameMain + "'"
    		        );
    		    
    		    // Get only the first enable child DDA
    		    // and log warning if there where more child dda
    		    int count = 0;
    		    while(rs.next())
    		    {
    	    		if (!rs.getBoolean("ena_flg")) {
    	    			continue;
    	    		}
    	    		
    	    		count++;
    	    		if (count == 1) {
	    	    		childDda = getDdaActionFactory()
	    	    					.new ChildDdaAction(
	    	    						rs.getString("dda_child_id")
	    	    						, DdaUtils.splitCSV(rs.getString("child_flds"))
	    	    		);	
    	    		}		
    		    }
    		    if (count > 1) {
    		    	log.warn("MTF DDA: Multiple Child DDA for: " + frmMain.getIdentifier());
    		    }
    		}
    		catch (MocaException e) {
    		    log.error("MOCA Exception (" + e.getErrorCode() + ") - "
    		        + e.getMessage());
    		}
    	}

    	
    	private void loadDda_ActionLinks(String frmName)
    			throws XFailedRequest {
    	
    		/* TODO: Fk - FUNCTION KEYS ARE TRICKY...
    		 * - Do I need to consider unbinding?.. (test)
    		 * - Gold key will be 10+ and use srtseq to bind against FK
    		 */

            String frmNameMain = DdaProperties.getFormNameWithoutSuffix(frmName);

    		MocaResults rsDdaAction;
    		try {
    		    rsDdaAction = session.executeCommand(
    		    	"get dda actions "
    		        + " where dda_id = '" + frmNameMain + "'"
    		        );
    		    
    		    // How to handle too many Fk actions?....
    		    // Fk 0..9 map directly to their Fk
    		    // Fk 10..19 map to gold keys
    		    while(rsDdaAction.next())
    		    {
    		    	String action = rsDdaAction.getString("action");
    		    	String fkCaption = "<unknown>";
    		    	
    		    	List<String> actFlds = 
    		    			DdaUtils.splitCSV(rsDdaAction.getString("action_flds"));
    		    	
    				MocaResults rsDdaInfo;
    				rsDdaInfo = session.executeCommand(
    			    	"list dda "
    			        + " where dda_id = '" + action + "'"
    			        );
    				if (rsDdaInfo.next()) {
    					fkCaption = rsDdaInfo.getString("mls_text");
    				}
    		    	
    		    	Integer fkValue = rsDdaAction.getInt("srtseq");
    		    	
    		    	// Setup Virtual Key (VK)
    		    	char fkIdx = fkValue.toString().charAt(0);
    		    	int fkMask = (fkValue > 10)
    		    					? IVirtualKey.MASK_LVL_GOLD
    		    					: IVirtualKey.MASK_LVL_NONE;
    		    	IVirtualKey vk = new CVirtualKey("VKID_F"+fkIdx,fkMask);
    		    	
    		    	

    		    	// TODO: FIX UNBIND
    		    	// Unbind all default form commands for this VK
//    		    	List<ICommand> lstCommands
//    		    		= frmMain.getCommands(vk.getStateModifierMask());
//    		    	if (lstCommands != null) {
//    		    		for (ICommand c : lstCommands) {
//    		    			try {
//    		    				frmMain.unbind(c);
//    		    			}
//    		    			catch (Exception ex) {
//    		    				// muffle out... (throws XInvalidArg, XInvalidRequest)
//    		    			}
//    		    		}
//    		    		
//    		    	}
    		    	
    		    	// Bind new command with this VK
    		    	ICommand cmd 
    		    		= getNewFkeyActionCommand(
		    				  action,fkIdx
		    				  , fkCaption
		    				  , actFlds
    		    		  );
    		    	cmd.setVisible(false);
    		    	frmMain.bind(cmd);
    		    	cmd.bind(vk);
    		    	
    		    }
    		}
    		catch (MocaException e) {
    		    log.error("MOCA Exception (" + e.getErrorCode() + ") - "
    		        + e.getMessage());
    		}
    	}
    	
    }

    public class DdaResultsWidget extends CDDATextSelection {

		private MocaResults rs;
        
        public DdaResultsWidget(String _strWidgetId, IContainer _container)
				throws XInvalidArg {
        	
        	// emulate: createTextSelection(...)
			super(_strWidgetId, _container);
        	segDef.add(this);
        	
        	// set properties...
            setEnabled(true);
            setVisible(true);
            setCompact(false);
            ((AInteractiveWidget)this).setTabIndex(1000);
            setShowSelection(false);
            setAutoAccept(false);
            setItemLines(1);
            
            actList = getDdaActionFactory().new FieldActions().getListActions();
            addWidgetAction(actList);
		}
        
		
		public void load(String mcmd) throws NotFoundException, MocaException {

			String strInto = "";
			if (mcmd != null && !mcmd.trim().isEmpty()) {
				strInto = " into :" + DdaResultsWidgetName;
			}
			
    		this.setDisplayFields(DdaUtils.convertToCSV(displayFieldsVarNam));	
    		
    		if (checkDisplayGridTitle()) {
    		    mcmd = mcmd + " >> res | populate grid title into resultset ";
    		}
            rs = null;
            rs = session.executeDSQL(mcmd + strInto); 
            CMtfUtil.getResults(display);
            rs = session.getGlobalMocaResults();
            rs.reset();
		}
		
		/* This function tells if the grid title should be display on RF screen.
		 */
		private boolean checkDisplayGridTitle() {
		    if(grid_prop != null && grid_prop.indexOf("displayTitle=1") >= 0) {
		        setDisplayGridTitle(true);
		        return true;
		    }
		    else {
		        setDisplayGridTitle(false);
		        return false;
		    }
		}
		
		public boolean onFieldExit() {
			// TODO:  this call needs be part of superclass onFieldExit for this widget. (no time now).
			
			// Need to manually point to MocaResults.Row
			// that matches the selected entry in the list.
			
			int idx = this.getSelectedIndex()+1;
			
			if (rs == null || rs.getRowCount() == 0 || rs.getRowCount() < idx) {
				log.error("MTF DDA: Fail to bind list selection to MocaResult row.");
				return false;
			}
			
			rs.reset();
			for (int i=0; i <idx; i++) {
				rs.next();
			}
			
			return true;
		}
		
		public void setItemLines(String grid_prop) {
			
			// Use this to setup ItemLines
			// based on DDA Grid Prop value (itmlin=999)
			
			// Grid Properties can have multiple valuees..
			// ie. xxx=123|itmlin=1|zzz=abcd|etc=...
			
			int itmLines = 1;
			
			// TODO: Parse grid_prop and setup item lines
			// Validate values to be setup or default to 1 
			
			
			setItemLines(itmLines);
		}
		

		@Override
		public void clear() {
			super.clear();
			rs = null;
		}

		public void setDisplayFields(String csvFields) {
			this.setDspFields(csvFields);
		}
		public List<String> getDisplayFields() {
			return this.getDspFields();
		}

		public void setReturnFields(String csvFields) {
			this.setRetFields(csvFields);
		}
		public List<String> getReturnFields() {
			return this.getRetFields();
		}
        public MocaResults getMocaResults() {
        	return rs;
        }

		private static final long serialVersionUID = 0L;
    }
	
    public class ActionFactory {

	    public class FieldActions {
	
	    	public CWidgetActionAdapter getListActions() {
	    		CWidgetActionAdapter action = null;
	    		
	    		switch(getDdaFormMode())
	    		{
	    		case QUERY:
	    			action = null;
	    			break;
	    		case RESULTS:
	    			action = new DdaMode_Results_Ctl_DdaResults();
	    			break;
	    		case ACTION:
	    			action = null;
	    			break;
	    		case EXECUTE:
	    			action = null;
	    			break;
	    		default:    			
	    			log.warn("MTF DDA: UNKNOWN DDA List Action - " + getDdaFormMode());
	    			action = null;
	    			break;
	    		}
	    		
	    		return action;
	    	}
	
	        private class DdaMode_Results_Ctl_DdaResults extends CWidgetActionAdapter {
	        	
	            public boolean onFieldEntry(IInteractiveWidget _ef) throws Exception {

	            	// Save locally and reset...
	            	boolean isfKeyMcmdExecuted = fKeyMcmdExecuted;
	            	boolean isfKeyFlowToNonDda = fKeyFlowToNonDda; 
			        fKeyMcmdExecuted = false;
			        fKeyFlowToNonDda = false;
			        

	            	// TODO: Clean up. Avoided if we handle by supleclass action for this control.
	            	if (_ef instanceof DdaResultsWidget) {
	            		DdaResultsWidget c = (DdaResultsWidget) _ef;
	            		
	            		// --- Do we have a ResultSet Item to focus?...
	            		int idx = c.getSelectedIndex();
	            		
	            		if (idx == 0 && c.checkDisplayGridTitle()) {
	            		    //When displaying title, skip first row which is title row.
	            		    idx = 1;
	            		    log.trace("Display title row, move first row to 2nd row.");
	            		}
	            		if (idx >= 0) {
	            			MocaResults rs = c.getMocaResults();
	            			rs.reset();
	            			for (int i=0; i <idx+1; i++) {
	            				rs.next();
	            			}
	            		}

	            		// -- ALWAYS REFRESH - except....
	            	    // -- SKIP REQUERYING - Special condition...
	            		// This happens when idx of the list is 0, 
	            		// and we try to move to the previous record.
	            	    if (!(idx ==0 && (!(isfKeyMcmdExecuted && isfKeyFlowToNonDda))))	
	            	    {
	    	                // If there is no MCMD to execute just fail and exit...
	    	                if (dda_cmd == null || dda_cmd.isEmpty()) {
	    	                	return false;
	    	                }
	    	                
	    		            // Output an informational message. 
	    		            display.beep();
	    		            frmMain.displayMessage(MtfConstants.STS_PROCESSING);
	    		            
	    		            try {            	
	    		            	resGrid.load(
	    			                    DdaUtils.buildDdaMocaCommand(
	    			                    		display
	    			                    		,dda_cmd
	    			                    		,mcmdFields
	    			                    		,promptFields)
	    			            );
	    		            }
	    		            catch (NotFoundException e) {
	    		                // Inform user about any issue with the resolution command
	    		                // and keep focus in current control.
	                            display.beep();

	                            // TODO: IMPROVE ERROR TO NON-TECHNICAL MESSAGE
	                            // Msg: No Results. Flowing back.
	                            
	                            String msg 
	                            	= "(" + Integer.toString(e.getErrorCode()) + ") " 
	                            	+ e.getLocalizedMessage();
	                            
	                            log.info(msg);
	                            if (!(isfKeyMcmdExecuted || isfKeyFlowToNonDda)) {
		                            frmMain.promptMessageAnyKey(msg);	
	                            }

//	                            frmMain.formReturn();
	                            frmMain.formBack();
	    		            }
	    		            catch (MocaException e) {
	    		                // Inform user about any issue with the resolution command
	    		                // and keep focus in current control.
	                            display.beep();

	                            String msg 
	                            	= "(" + Integer.toString(e.getErrorCode()) + ") " 
	                            	+ e.getLocalizedMessage();
	                            
	                            log.error(msg);
	                            frmMain.promptMessageAnyKey(msg);

	                            frmMain.formBack();
	    		            }
	    		            finally
	    		            {
	    			            frmMain.resetMessageLine();
	    		            }
	            		}
	            	}
	            	
	            	// If we don't have results just return 
	            	MocaResults rs = resGrid.getMocaResults();
	            	if (rs == null || rs.getRowCount() == 0) {
	            		log.warn("MTF DDA: Query completed successfully - but NO RESULTS.  Going back then...");
	            		frmMain.formBack();
	            	}
	            	
	                return true;
	            }
	
	            public boolean onFieldExit(IInteractiveWidget _ef) throws Exception {
	            	
	            	resGrid.onFieldExit();

	            	
	            	// TODO: THIS FLOW SECTION SHOULD BE GENERIC TO OTHER CONTROLS....
	            	
	            	/* ------------------------------------
	            	 * If DDA Form has a CHILD DDA, this will be the default flow action.
	            	 * Else, if the form has FK_8 we will consider this a default action.
	            	 */

	            	// Check for Child DDA
	            	if (childDda != null) {
	            		AFormLogic frm = 
						  getDdaForm(
							DdaProperties.generateFormName(
									frmMain.getIdentifier() + FrmTypTkn 
									+ childDda.getDdaId(),DdaProperties.FormMode.RESULTS)
							, EFlow.SHOW_FORM
						);
	            		
	            		// Overwrite the bind query fields to use DdaChild link fields.
	            		if (frm instanceof DdaFactory)
	            		{
	            			DdaFactory ddaFrm = (DdaFactory) frm;
	            			ddaFrm.mcmdFields = childDda.getLinkFields();
	            		}
	            		
	            		frm.run();
	            	}
	            	// Check for FK_8
	            	else {
	    		    	IVirtualKey vk = new CVirtualKey("VKID_F8",IVirtualKey.MASK_LVL_NONE);
                        ICommand c = frmMain.getCommand(frmMain, "8", vk.getStateModifierMask());
                        if (c != null) {

    		    			try {
    		    				c.execute(frmMain);
    		    			}
    		    			catch (Exception ex) {
    		                    if (ex instanceof XFormAlreadyOnStack) {
    		                        throw (XFormAlreadyOnStack) ex;
    		                    }
    		                    else {
	    		    				log.error("MTF DDA: Default FK Error - " + c.getCommandId());
	    		    				ex.printStackTrace();
    		                    }
    		    			}
                        }
	            	}

	            	// Getting here means - NOTHING TO DO.. (no exit)
	            	return false;
	            }
	        }        
	    }

	    
	    public class FormActions {
	    	
	    	public CWidgetActionAdapter getFormActions() {
	    		CWidgetActionAdapter action = null;
	    		
	    		switch(getDdaFormMode())
	    		{
	    		case QUERY:
	    			action = new DdaMode_Query();
	    			break;
	    		case RESULTS:
	    			action = new DdaMode_Results();
	    			break;
	    		case ACTION:
	    			action = new DdaMode_Action();
	    			break;
	    		case EXECUTE:
	    			action = new DdaMode_Execute();
	    			break;
	    		default:    			
	    			log.warn("MTF DDA: UNKNOWN DDA Form Action - " + getDdaFormMode());
	    			action = new DdaMode_Default();
	    			break;
	    			
	    		}
	    		
	    		return action;
	    	}
	
	        private class DdaMode_Default extends CWidgetActionAdapter {
	            public boolean onFormEntry(IForm _frm) throws Exception {
	            	// Allow the entry.
	                return true;
	            }
	
	            public boolean onFormExit(IForm _frm) throws Exception {
	                // ALWAYS FALSE. 
	                // Control exit result above.
	                return false;
	            }
	        }
	        
	        private class DdaMode_Query extends CWidgetActionAdapter {
	
	            public boolean onFormEntry(IForm _frm) throws Exception {

	            	frmMain.clearForm();
	            	
	            	// Allow the entry.
	                return true;
	            }
	
	            public boolean onFormExit(IForm _frm) throws Exception {

	            	// Flow style handles a special scenario when NO PROMPT FIELDS are defined.
	            	// When such scenario, the QUERY Form will automatically execute
	            	// and go to RESULTS Form.
	            	//
	            	// The problem is returning from the Results.  Which really 
	            	// flows back to Query and goes back to Results automatically...
	            	// This creates an infitive loop.
	            	//
	            	// For that reason we use SHOW_FORM mode when no PROMPT FIELDS exists.
	            	
	            	EFlow flowStyle = EFlow.EXECUTE_FORM;
	            	if (promptFields == null || promptFields.isEmpty())
	            	{
	            		flowStyle = EFlow.SHOW_FORM;
	            	}
	            	
	            	// Get form we are flowing to.
	        		AFormLogic frm = 
					  getDdaForm(
			            DdaProperties.generateFormName(_frm,DdaProperties.FormMode.RESULTS)
						, flowStyle
					);
	        		
	        		// Set the mcmd link fields.
	        		if (frm instanceof DdaFactory)
	        		{
	        			DdaFactory ddaFrm = (DdaFactory) frm;
	        			ddaFrm.mcmdFields = promptFields;
	        		}
	        		
	                frm.run();
	                
	                // No PROMPT Fields, so return one form more...
	                if (flowStyle == EFlow.SHOW_FORM)
	                {
	                	frmMain.formReturn();
	                }
	            
	                // ALWAYS FALSE. 
	                // Control exit result above.
	                return false;
	            }
	        }
	
	        private class DdaMode_Results extends CWidgetActionAdapter {
	
	            public boolean onFormEntry(IForm _frm) throws Exception {
	                log.info("Now clear global.dda_mode");
	                display.setVariable("global.dda_mode", ""); //Sam: clear this remove side affect.

	            	// In case we need to skip refresh (future...)
//	            	if (resGrid != null 
//	            			&& resGrid.getSelectedIndex() >= 0) {
//	            		// skip refresh
//	            		return true;
//	            	}
	    	        
	            	// Always Refresh - cleanup
	            	frmMain.clearForm();	            	
	            	if (resGrid != null) resGrid.clear();
	            	
	                return true;
	            }
	
	            public boolean onFormExit(IForm _frm) throws Exception {
	
	            	frmMain.formBack();

	        		
	                // ALWAYS FALSE. 
	                // Control exit result above.
	                return false;
	            }
	        }
	
	        private class DdaMode_Action extends CWidgetActionAdapter {
	
	        	/* Note: When a FKEY is executed... 
	        	 * these are the actions that will be taken...
	        	 */
	        	
	            public boolean onFormEntry(IForm _frm) throws Exception {
	            	
	            	frmMain.clearForm();
	            	fKeyMcmdExecuted = false;
	            	fKeyFlowToNonDda = false;
	            	
	            	// Allow the entry.
	                return true;
	            }
	
	            public boolean onFormExit(IForm _frm) throws Exception {   
	
	                // If there is no MCMD to execute just fail and exit...
	                if (dda_cmd == null || dda_cmd.isEmpty()) {
	                	return false;
	                }
	                
		            // Output an informational message. 
		            display.beep();
		            frmMain.displayMessage(MtfConstants.STS_PROCESSING);
		            
		            try {
		                MocaResults rs = null;
		                rs = session.executeDSQL(
			                    DdaUtils.buildDdaMocaCommand(
			                    		display
			                    		,dda_cmd
			                    		,mcmdFields
			                    		,promptFields) 
		                );
		                
		                // No Error - messages...
		                // Results are shown after flowing back...
		            }
		            catch (NotFoundException e) {
		                log.info("MOCA Exception (" + e.getErrorCode() + ") - "
		                        + e.getMessage());
	
	                    frmMain.displayErrorMessage(e);
		            }
		            catch (MocaException e) {
		                log.error("MOCA Exception (" + e.getErrorCode() + ") - "
		                        + e.getMessage());
	
	                    frmMain.displayErrorMessage(e);
		            }
		            finally
		            {
			            // clear message line			            
			            frmMain.resetMessageLine();
		            }
	    	        
		            // ALWAYS USE - RETURN
		            // Need to continue the flow in the previous context.
		            frmMain.formReturn();
	            	
	                // ALWAYS FALSE. 
	                // Control exit result above.
	                return false;
	            }
	        }
	        

	        private class DdaMode_Execute extends CWidgetActionAdapter {
	        	private boolean showSuccess = false;
	        	
	            public boolean onFormEntry(IForm _frm) throws Exception {
	            	// Allow the entry.
	            	
	            	// DISPLAY SUCCESS
	            	if (showSuccess)
	            	{
			            frmMain.displayMessage("err0");
	            	}
	            	
	            	showSuccess = false;
	            	
	                return true;
	            }
	
	            public boolean onFormExit(IForm _frm) throws Exception {   
	
	                // If there is no MCMD to execute just fail and exit...
	                if (dda_cmd == null || dda_cmd.isEmpty()) {
	                	return false;
	                }
	                
		            // Output an informational message. 
		            display.beep();
		            frmMain.displayMessage(MtfConstants.STS_PROCESSING);
		            
		            try {
		                MocaResults rs = null;
		                rs = session.executeDSQL(
			                    DdaUtils.buildDdaMocaCommand(
			                    		display
			                    		,dda_cmd
			                    		,mcmdFields
			                    		,promptFields) 
		                );
		            }
		            catch (NotFoundException e) {
		                log.info("MOCA Exception (" + e.getErrorCode() + ") - "
		                        + e.getMessage());
	
	                    frmMain.displayErrorMessage(e);
		            }
		            catch (MocaException e) {
		                log.error("MOCA Exception (" + e.getErrorCode() + ") - "
		                        + e.getMessage());
	
	                    frmMain.displayErrorMessage(e);
		            }
		            finally
		            {
			            // Display lookup results 
			            frmMain.resetMessageLine();
		            }
		            
		            // Display success
		            frmMain.clearForm();
	            	showSuccess = true;
                    throw new XFormAlreadyOnStack(frmMain.getIdentifier(), 
                            MtfConstants.EFlow.EXECUTE_FORM); 
	    	            
	            	
	                // ALWAYS FALSE. 
	                // Control exit result above.
	                // return false;
	            }
	        }
	    }

		public class ChildDdaAction {
		
			private String _ddaId= "";
			private List<String> _lnkFields;
			
			public ChildDdaAction(String childDdaId, List<String> linkFields) {
				setDdaId(childDdaId);
				setLinkFields(linkFields);
			}
			
		    
		    public String getDdaId() {
				return _ddaId;
			}
			private void setDdaId(String _ddaId) {
				this._ddaId = _ddaId;
			}
			public List<String> getLinkFields() {
				return _lnkFields;
			}
			private void setLinkFields(List<String> _lnkFields) {
				this._lnkFields = _lnkFields;
			}
		}
		
	
        public void FkeyBack_Execute(IContainer _container) throws Exception {
        	
        	// clear this form
        	frmMain.clearForm();
        	
        	// how to flow back?
        	boolean callFormBack = false;
        	AFormLogic fl = null;
        	IForm frm = display.getPreviousFormOnStack();
        	
        	if (frm != null) {
        		fl = display.getInstantiatedForm(frm.getIdentifier());
        	}

    		if (fl != null
    				&& fl instanceof DdaFactory
    				&& ((DdaFactory) fl).getDdaFormMode() == FormMode.QUERY) {
    			callFormBack = true;
    		}
        	
        	if (callFormBack) {
        		frmMain.formBack();
        	}
        	else {
            	//frmMain.formReturn();
        	    frmMain.formBack();
        	}
        }

		
        public void FkeyAction_Execute(IContainer _container, String _ddaId, List<String> _actionFields) throws Exception {
        	
        	/* When a DDA Form - FK action executes...
        	 * We flow to another virtual form to execute the command
        	 * and then return with the results...
        	 * This is to handle setting the context better and reading results.
        	 * Think of it as a temporary space....
        	 * 
        	 * Notice!! - we only do it for "DdaFactory" instances.
        	 */
        	
        	// Get the Action form to execute.
            MocaResults ddars;
            ddars = session.executeCommand(
                "list dda "
                + " where dda_usage = '" + DdaMstUsage + "' "
                + "   and dda_id = '" + _ddaId + "' "
                );
            
            ddars.next();

            dda_typ = ddars.getString("dda_typ");
            dda_auto_find = ddars.getInt("auto_find");
            
            log.trace("Execute FKey for dda:" + _ddaId + ", dda_typ:" + dda_typ + ", dda_auto_find:" + dda_auto_find);
            
            AFormLogic frm = null;
            
            if (dda_typ.equals("Q") && dda_auto_find != 0)
            {
                
                  frm = getDdaForm(
                            DdaProperties.generateFormName(
                                    frmMain.getIdentifier() + FrmTypTkn
                                    + _ddaId,DdaProperties.FormMode.RESULTS)
                            , EFlow.SHOW_FORM
                        );
            }
            else {
    		       frm = getDdaForm(
		            		DdaProperties.generateFormName(
		            				frmMain.getIdentifier() + FrmTypTkn
		            				+ _ddaId,DdaProperties.FormMode.ACTION)
		            		, EFlow.SHOW_FORM
		                );
            }

    		
    		// -- FIREWALL !! ONLY DdaFactory instances...
    		if (!(frm instanceof DdaFactory)) {
    			return;
    		}
			
    		
    		// -- SETUP CONTEXT BEFORE EXECUTE MCMD
    		
    		// Setup mcmd fields to the ones used by the action
			DdaFactory ddaFrm = (DdaFactory) frm;
			ddaFrm.mcmdFields = _actionFields;
			
			// Force refresh of this form once action completes.
			// But we also need to put the cursor back to the
			// index or close to it when we return
			int idxItem = -1;
			if (resGrid != null) {
				idxItem = resGrid.getSelectedIndex();
			}
    		
			log.trace("resGrid.getSelectedIndex() is:" + idxItem);
			
    		// -- EXECUTE COMMAND - by running the RF Form
			// !!- DONT CALL THE DdaFactory.run()
    		frm.run();
            fKeyMcmdExecuted = true;
    		
    		// -- CONTINUE HERE...
    		// After executing the mcmd for this action.
            MocaResults rs = session.getGlobalMocaResults();
			MocaException ex = session.getGlobalMocaException();
    		
			// -- ANY ERRORS?  Just Exit... (firewall)
			if (ex != null && ex.getErrorCode() != MtfErrors.eOK) {
				return;
			}
			
    		
    		// -- HANDLE FLOW : Next Steps...

			/* Based on the results, 
			 * We might need to flow to another form...
			 * Else, it was a basic background mcmd execution...
			 * 
			 * When flowing we have 2 special fields:
			 * - rfdda_flowto = next form
			 * - rfdda_flowstyle = flow style to use
			 *      (default: EXECUTE_FORM)
			 *      
			 * The rest of the fields will be use to set context.
			 * Every field we will try to set in the "next form"
			 * unless the field name is in the style of: form.field
			 * For example:  INIT_POLICIES.prvfrm = UNDIR_PICKUP
			 * 
			 */
			
			String fkeyFrmName = _ddaId;
			
			// Is this MocaResult requesting to flow into another form?...
			if (rs != null && rs.getRowCount() > 0 && rs.containsColumn(RsFld__rfdda_flowto)) {

				// Validate call... only 1 record
				if (rs.getRowCount() > 1) {
					log.error("MTF DDA: [" + fkeyFrmName + "] - FKey flow error - multiple records.");
					return;
				}
				rs.next();
				
				// Setup flow context
				String frmFlowTo = rs.getString(RsFld__rfdda_flowto);
				if (frmFlowTo == null || frmFlowTo.isEmpty()) {
					log.error("MTF DDA: [" + fkeyFrmName + "] - FKey flow error - no form specified.");
					return;
				}
				
				EFlow frmFlowStyle = null;
				if (rs.containsColumn(RsFld__rfdda_flowstyle)) {
					frmFlowStyle = DdaUtils.getEFlow(rs.getString(RsFld__rfdda_flowstyle));
				}
				if (frmFlowStyle == null)
				{
					frmFlowStyle = EFlow.EXECUTE_FORM;
				}

	            AFormLogic nxtFrm = display.createFormLogic(frmFlowTo,frmFlowStyle);
	            if (nxtFrm == null) {
					log.error("MTF DDA: [" + fkeyFrmName + "] - FKey flow error - form (" + frmFlowTo + ") not found.");
					return;
	            }
	            

	            // -- Setup Context for the next form
	            
	            for (int i = 0; i < rs.getColumnCount(); i++){
	            	String colName = rs.getColumnName(i);
	            	
	            	// skip
	            	if (colName == null
	            			|| colName.equals(RsFld__rfdda_flowto)
	            			|| colName.equals(RsFld__rfdda_flowstyle)) {
	            		continue;
	            	}
	            	
	            	// target correct - [form & field] to set value
	            	String setFormField = "";
	            	if (!colName.contains(".")) {
	            		setFormField = frmFlowTo + "." + colName;
	            		
	            	}
	            	else
	            	{
		            	setFormField = colName;
	            	}
	            	
	            	// get value to push
	            	Object v = rs.getValue(i);
	            	String setValue = "";
	            	try {
		            	if (v != null) {
		            		setValue = rs.getValue(i).toString(); 
		            	}

		            	// set value
		            	display.setVariable(setFormField, setValue);	
	            	}
	            	catch (Exception e) {
    					log.warn("MTF DDA: [" + fkeyFrmName + "] - FKey flow error - setting field (" + rs.getColumnName(i) + ").");
	            	}	            			
	            }
	            
	            
	            // -- Execute next form
	            fKeyFlowToNonDda = true;
                nxtFrm.run();

                // TODO: TEST - NEED TO CLEAR FORM?.. vs Exception flow...
//				frmMain.clearForm();
//				frmMain.resetMessageLine();


			}
			// Or was just a basic mcmd call..
			else {
    			// -- RETURN TO CALLER
    			// Only refresh on successful executions
    			if (ex == null || ex.getErrorCode() == MtfErrors.eOK) {
    				frmMain.promptMessageAnyKey("err0");
		            		            
    				frmMain.clearForm();
    				frmMain.resetMessageLine();
    			}
			}
			
    		

			// TODO: SETUP PREVIOUSLY SELECTED ITEM...
    		
        }

    }
}
