/*
 *  $URL$
 *  $Revision$
 *  $Author$
 *  $Date$
 *  
 *  $Copyright-Start$
 *
 *  Copyright (c) 2008
 *  RedPrairie Corporation
 *  All Rights Reserved
 *
 *  This software is furnished under a corporate license for use on a
 *  single computer system and can be copied (with inclusion of the
 *  above copyright) only for use on such a system.
 *
 *  The information in this document is subject to change without notice
 *  and should not be construed as a commitment by RedPrairie Corporation.
 *
 *  RedPrairie Corporation assumes no responsibility for the use of the
 *  software described in this document on equipment which has not been
 *  supplied or approved by RedPrairie Corporation.
 *
 *  $Copyright-End$
 */

package com.alx.les.dda;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.redprairie.moca.EditableResults;
import com.redprairie.moca.MocaException;
import com.redprairie.moca.MocaResults;
import com.redprairie.moca.MocaType;
import com.redprairie.moca.SimpleResults;
import com.redprairie.mtf.MtfConstants;
import com.redprairie.mtf.CMtfUtil;
import com.redprairie.mtf.MtfInterruptedException;
import com.redprairie.mtf.contract.terminal.ITerminalDriver;
import com.redprairie.mtf.entities.CMcsFormConfig;
import com.redprairie.mtf.entities.CVarConfig;
import com.redprairie.mtf.entities.CVarDef;
import com.redprairie.mtf.exceptions.XFormAlreadyOnStack;
import com.redprairie.mtf.exceptions.XInvalidArg;
import com.redprairie.mtf.exceptions.XInvalidRequest;
import com.redprairie.mtf.exceptions.XMissingObject;
import com.redprairie.mtf.foundation.presentation.CDisplayItem;
import com.redprairie.mtf.foundation.presentation.CTranslationProvider;
import com.redprairie.mtf.foundation.presentation.CTranslationResult;
import com.redprairie.mtf.foundation.presentation.CVirtualKey;
import com.redprairie.mtf.foundation.presentation.CWidgetActionPerformedDelegate;
import com.redprairie.mtf.foundation.presentation.CWidgetEvent;
import com.redprairie.mtf.foundation.presentation.IAutoAcceptableWidget;
import com.redprairie.mtf.foundation.presentation.IContainer;
import com.redprairie.mtf.foundation.presentation.IEntryField;
import com.redprairie.mtf.foundation.presentation.IForm;
import com.redprairie.mtf.foundation.presentation.ITextSelection;
import com.redprairie.mtf.foundation.presentation.ITranslation;
import com.redprairie.mtf.foundation.presentation.IVirtualKey;
import com.redprairie.mtf.foundation.presentation.IWidgetActionValidator;
import com.redprairie.mtf.terminal.presentation.*;
import com.redprairie.mtf.util.BidiUtils;

/**
 * A {@link CDDATextSelection }widget presents the user with a list of text items,
 * and allows the user to select an entry from the list.
 * <p>
 * Although the text selection may be presented as a "combo-box" or "drop-down",
 * the user is <strong>not </strong> able to modify the selected text.
 * </p>
 * 
 * <b><pre>
 * Copyright (c) 2009 RedPrairie Corporation
 * All Rights Reserved
 * </pre></b>
 * 
 * @author smedic
 * @version $Revision$
 */
public class CDDATextSelection extends ADataWidget implements ITextSelection,
        ISelectionProvider, IAutoAcceptableWidget {

    /**
     * Prime constructor.
     * 
     * @param _strWidgetId Widget identifier
     * @param _container Container
     * @throws XInvalidArg
     */
    public CDDATextSelection(String _strWidgetId, IContainer _container)
            throws XInvalidArg {

        super(_strWidgetId, _container.getDisplay(), _container);

        _strWidgetId = getDisplay().getWidgetResourceProvider()
            .normalizeWidgetId(_strWidgetId);

        _lstCtlItems = new LinkedList<ItemData>();
        retFields = new LinkedList<String>();
        dspFields = new LinkedList<String>();
        idxSelected = -1;
        cDisplayRows = -1;
        autoRows = true;
        cchDisplayCols = -1;
        autoColumns = true;
        setShowMarkers(false);
        setShowSelection(false);
        setCircularNavigation(false);
        _fAutoAccept = false;
        fCompact = false;
        cchSelectionPadding = 1;
        scrollMode = SCROLL_MODE_DOWN;

        selprovDelegate = new CSelectionProviderDelegate();
        
        // We need to determine the base writing direction of the
        // interaction mechanism. This is necessary because for RTL
        // scripts, the interaction always starts at the rightmost
        // position in a text selection.
        String localeId = getDisplay().getSession().getGlobalVar("LOCALE_ID");
        isRTL = BidiUtils.isRightToLeftBaseDirection(localeId);

        try {
            List<String> lststrItems = getDisplay().getWidgetResourceProvider()
                .fetchStrings(_strWidgetId, RESKEY_WIDGET_ITEMS_LIST);

            Iterator<String> istrItem = lststrItems.iterator();
            while (istrItem.hasNext()) {

                String[] astrItemAndData = 
                    StringUtils.split((String) istrItem.next(), '=');

                String itemDisplay = astrItemAndData[0];
                String itemValue = null;

                if (astrItemAndData.length > 1) {
                    itemValue = astrItemAndData[1];
                }
                ItemData itemData = new ItemData(itemDisplay, itemDisplay, itemValue);
                getItems().add(itemData);
                
            }

            setText(getDisplay().getWidgetResourceProvider().fetchString(
                _strWidgetId, RESKEY_WIDGET_TEXT_STRING));

        }
        catch (XMissingObject exmissing) {
        }
        catch (MtfInterruptedException e) {
            // We need to re-throw this exception to make sure that it is
            // not trapped by the catch (Exception) below.
            throw e;
        }
        catch (Exception ex) {
            log.warn("Failed to set default text selection items", ex);
        }

        try {
            if (getDisplay().getWidgetResourceProvider()
                    .fetchString(_strWidgetId, RESKEY_WIDGET_FLAG_COMPACT)
                    .equalsIgnoreCase("true")) {
                log.trace("Text selection [" + _strWidgetId
                    + "] set to COMPACT");
                fCompact = true;
            }
        }
        catch (XMissingObject exignore) {
        }

        try {
            if (getDisplay().getWidgetResourceProvider()
                    .fetchString(_strWidgetId, RESKEY_WIDGET_AUTOACCEPT_FIELD)
                    .equalsIgnoreCase("true")) {
                log.trace("VK_ACCEPT set to do an ACCEPT not a NEXT_FIELD ["
                    + _strWidgetId + "]");
                _fAutoAccept = true;
            }
        }
        catch (XMissingObject exignore) {
        }
        
        // ----- tabOrder PROPERTY
        try {
            super.setTabIndex(Integer.parseInt(getDisplay().getWidgetResourceProvider()
                    .fetchString(_strWidgetId, RESKEY_WIDGET_TABORDER_FIELD)));
        } 
        catch (XMissingObject exignore) {
            // Ignore
        }
        catch (MtfInterruptedException e) {
            // We need to re-throw this exception to make sure that it is
            // not trapped by the catch (Exception) below.
            throw e;
        }
        catch (Exception ex) {
            log.warn("Failed to set entry field tab order", ex);
        }

        String terminalType = ((CDisplay) getDisplay()).
            getConnection().getTerminalType();

        // ----- dislayWidth PROPERTY
        String strDspWid = "";

        strDspWid = getWidgetResourceValue(_strWidgetId,
            RESKEY_WIDGET_DISPLAYWIDTH_FIELD, terminalType);

        // Check to see if the specified width is a number or a constant.
        if ((strDspWid != null) && (strDspWid.length() != 0)) {
            if (StringUtils.isNumeric(strDspWid)) {
                cchDisplayCols = Integer.parseInt(strDspWid);
                autoColumns = false;
            }
            else {
                // OK. So, this must be a constant. Look it up
                // in one of constants files using Java Reflection API.
                int tempDspWid = getNumericConstantValue(strDspWid);
    
                if (tempDspWid > 0) {
                    cchDisplayCols = tempDspWid;
                    autoColumns = false;
                }
            }
        }
        log.trace("Display width set to [" + cchDisplayCols + "] for widget "
                + _strWidgetId + ".");

        // ----- lines PROPERTY
        String strLines = "";

        strLines = getWidgetResourceValue(_strWidgetId, RESKEY_WIDGET_LINES,
            terminalType);

        // Check to see if the specified width is a number or a constant.
        if ((strLines == null) || (strLines.length() == 0)) {
            lines = 1;
        }
        else if (StringUtils.isNumeric(strLines)) {
            lines = Integer.parseInt(strLines);
        }
        else {
            // OK. So, this must be a constant. Look it up
            // in one of constants files using Java Reflection API.
            int tempLines = getNumericConstantValue(strLines);

            if (tempLines > 0) {
                lines = tempLines;
            }
        }
        log.trace("Lines set to [" + lines + "] for widget " + _strWidgetId 
            + ".");

        // ----- height PROPERTY
        String strHgt = "";

        strHgt = getWidgetResourceValue(_strWidgetId, RESKEY_WIDGET_HEIGHT,
            terminalType);

        // Check to see if the specified width is a number or a constant.
        if ((strHgt != null) && (strHgt.length() != 0)) {
            if (StringUtils.isNumeric(strHgt)) {
                cDisplayRows = Integer.parseInt(strHgt);
                autoRows = false;
            }
            else {
                // OK. So, this must be a constant. Look it up
                // in one of constants files using Java Reflection API.
                int tempHgt = getNumericConstantValue(strHgt);
    
                if (tempHgt > 0) {
                    cDisplayRows = tempHgt;
                    autoRows = false;
                }
            }
        }
        log.trace("Height set to [" + cDisplayRows + "] for widget "
                + _strWidgetId + ".");
    }

    public String getText() {
        if (idxSelected != -1) {
            return ((ItemData) getItems().get(idxSelected)).getValue();
        }
        return "";
    }

    public void setText(String _strText) throws XInvalidArg {

        selectItem(_strText);

        if (idxSelected == -1) {
            getItems().add(new ItemData(_strText,_strText,null));
            selectItem(_strText);

            // ------ Need to recalc width
            if (autoColumns) {
                cchDisplayCols = -1;
            }
            if (autoRows) {
                cDisplayRows = -1;
            }
        }

        // ------ Invalidate display partially
        if (getContainer() != null) {
            ((AContainer) getContainer()).setLayoutStale(true);
        }
    }

    public List<ItemData> getItems() {
        return _lstCtlItems;
    }

    public Object getItem(int idx) throws XInvalidRequest {
        // Please note that for the MTF implementation
        // we always return an ItemData object.
        // Due to the interface, we have to return it as object.
        try {
            return _lstCtlItems.get(idx);
        }
        catch (IndexOutOfBoundsException ex) {
            // return null if out of bounds
            return null;
        }
    }

    public void setItems(List<String> _lststrItems) throws XInvalidArg {

        // ------ Check args
        if (_lststrItems == null) {
            throw new XInvalidArg(
                "List of selection items may not be null for {0}", this);
        }

        getItems().clear();
        for (Iterator<String> istrItem = _lststrItems.iterator(); istrItem.hasNext();) {
            String strItem = (String) istrItem.next();
            getItems().add(new ItemData(strItem, strItem, null));
        }

        // ------ Invalidate display completely

        if (autoRows) {
            cDisplayRows = -1;
        }
        if (autoColumns) {
            cchDisplayCols = -1;
        }

        if (getContainer() != null) {
            ((AContainer) getContainer()).setLayoutStale(true);
        }
    }

    public void selectItem(int _idx) throws XInvalidRequest {

        // ------ Check args
        if ((_idx < 0) || (_idx >= getItems().size())) {
            throw new XInvalidRequest("Item index out of range for {0}", this);
        }

        // ------ Select desired item
        idxSelected = _idx;
        selectItemForOldMtf();

        // ------ Invalidate display partially
        if (getContainer() != null) {
            ((AContainer) getContainer()).setLayoutStale(true);
        }
    }
    
    public void selectItem(String strItem) throws XInvalidArg {

        // ------ Sanity check
        if (strItem == null) {
            throw new XInvalidArg("Item may not be null for {0}", this);
        }
        
        // ------ Find and select item
        idxSelected = indexOfItemData(ItemDataField.DISPLAY, strItem);
        selectItemForOldMtf();

        // ------ Invalidate display partially
        if (getContainer() != null) {
            ((AContainer) getContainer()).setLayoutStale(true);
        }
    }
    
    public void selectByItemData(String itemValue) {
        
        // Sanity check for an early exit.
        if (itemValue == null) {
            throw new XInvalidArg("Item may not be null for {0}", this);
        }
        else if (getItems().isEmpty()) {
            log.error("Cannot select the specified item in the CDDATextSelection "
                + "list because the list is empty.");
            return;
        }
        
        // search for the item value and select it
        int idxValue = indexOfItemData(ItemDataField.VALUE, itemValue);
        if (idxValue >= 0) {
            idxSelected = idxValue;

            // Invalidate display partially
            if (getContainer() != null) {
                ((AContainer) getContainer()).setLayoutStale(true);
            } 
        }
        else {
            log.error("Could not select the specified item in the "
                + "CDDATextSelection list because it does not exist for the "
                + "passed in parameter.");
            return;
       }
    }    

    /**
     *@deprecated
     * 
     * Due to old MTF reading the return from global.retstr now we need to 
     * emulate this as well. An assumption is that the return value is of type
     * string. The use of this global variable should be @deprecated.
     * 
     * <br><br>
     * <b>NOTE:</b> Once all Java RDT forms are coded manually, this method can
     * be removed as no longer will be needed. Currently, it exists to support
     * converted old MTF screens.
     */
    @Deprecated 
    private void selectItemForOldMtf() {
        String retval = ((ItemData) getItems().get(idxSelected)).getValue();

        getDisplay().setVariable("global.retstr",
            (retval != null ? retval : null));
    }

    // ----------------------------------------------
    // GETTERS FOR ACCESSING ITEMDATA VALUES
    // ----------------------------------------------
    
    public String getSelectedItem() {
        return ((ItemData) getItems().get(idxSelected)).getValue();
    }
    
    /**
     * Get the Item number that will be displayed.
     * @return - displayed Item Number
     */
    public String getSelectedDisplayText() {
        return ((ItemData) getItems().get(idxSelected)).getDisplay();
    }

    /**
     * Get the translated Item Number.
     * @return - translated Item Number
     */
    public String getSelectedTranslationText() {
        return ((ItemData) getItems().get(idxSelected)).getTranslatedDisplay();
    }
    
    public int getSelectedIndex() {
        return idxSelected;
    }
    
    public boolean isDisplayGridTitle() {
        return isDisplayGridTitle;
    }
    
    public void setDisplayGridTitle(boolean val) {
        isDisplayGridTitle = val;
    }

    /**
     * Get the display string for an Item.
     * @param - the index the of the desired Item
     * @return the Display String
     */
    public String getDisplayString(int idx) throws XInvalidRequest {

        // ------ Check args
        if ((idx < 0) || (idx >= getItems().size())) {
            throw new XInvalidRequest("Item index out of range for {0}", this);
        }

        // ------ Return desired item
        ItemData item = getItems().get(idx);
        if (getBaseForm(this).isTranslationDisplayed()) {
            return item.getTranslatedDisplay();
        }
        else {           
            return item.getDisplay();
        }
    }

    public void setItem(int _idx, String _strItem) throws XInvalidArg,
            XInvalidRequest {

        // ------ Check args
        if (_strItem == null) {
            throw new XInvalidArg("Item may not be null for {0}", this);
        }

        if ((_idx < 0) || (_idx >= getItems().size())) {
            throw new XInvalidRequest("Item index out of range for {0}", this);
        }
        
        getItems().set(_idx, new ItemData(_strItem, _strItem, null));
        setRefreshRequired(true);
    }

    /**
     * Adds an item to the control.
     * 
     * @param itemDisplay
     * @param itemValue
     * @return selected item index
     * @throws XInvalidArg
     */
    public int addItem(String itemDisplay, Object itemValue) 
            throws XInvalidArg {
        // _itemValue is always String for MTF
        return addItem(itemDisplay, itemDisplay, (String) itemValue);
    }

    /**
     * Adds an item to the control with translation value.
     * 
     * @param itemDisplay
     * @param itemTranslation
     * @param itemValue
     * @return selected item index
     * @throws XInvalidArg
     */
    public int addItem(String itemDisplay, String itemTranslation, 
                       String itemValue) throws XInvalidArg {

        // ------ Sanity check
        if (itemDisplay == null) {
            throw new XInvalidArg("Item may not be null for {0}", this);
        }
        getItems().add(new ItemData(itemDisplay, itemTranslation, itemValue));

        // ------ Need to recalc width
        if (autoColumns) {
            cchDisplayCols = -1;
        }
        if (autoRows) {
            cDisplayRows = -1;
        }

        if (getItems().size() == 1) {
            selectItem(itemDisplay);
        }

        // ------ Return item index
        return idxSelected;
    }
    
    public void addItemsMocaRs(MocaResults rs) {
        
        // =====================================================================
        //                     IMPORTANT - PLEASE READ
        // 
        // This can get tricky since we currently don't know the whole picture.
        // There are old MTF API functions that set how to display the widget 
        // entries, but we currently don't have them implemented in the new MTF.
        // The good thing is that standard product forms do not call those 
        // API functions, which includes the following: SetListColumns(), 
        // SetListMaxFill(), etc. That being said, let's populate the 
        // CDDATextSelection widget based on what is currently known.
        // NOTE: SetReturnColumn() API Function indicates which column should 
        // be returned from the list when the user selects a row from the list.
        // Otherwise, the first field value will be returned.
        // =====================================================================
        
        // Clear the items from the control...  This is necessary so that
        // we do not re-populate the text selection object with the same data.
        getItems().clear();
        
        // OK, if this text selection is located on the LOOKUP_FORM, then we 
        // need to perform some special processing to get the var_nam of the
        // the return field because LOOKUP_FORM uses text selection widget 
        // in a different way that other forms. I.e. LOOKUP_FORM needs to get 
        // var_nam of the focused return field from where it was called. This 
        // is a focused field from which F2 function key was invoked and the
        // field is located on the previous form on stack.
        String returnField = "";
        
        try {
            if (getDisplay().getCurrentFormOnStack().getIdentifier()
                    .equals("LOOKUP_FORM")) {
                returnField = getDisplay().getPreviousFormOnStack()
                    .getLowestFocusedWidget().getUniqueId();
            }
            else {
                returnField = getDisplay().getCurrentFormOnStack()
                    .getLowestFocusedWidget().getUniqueId();
            }
        }
        catch (NullPointerException e) {
            // Ignore - text selection does not need to have the return
            // field. For example, text selection widget can be populated
            // with MocaResults during onFormEntry() of some form, which
            // means that the form may not have a focusable widget at that
            // time. In that case, NullPointerException may be thrown.
        }

        if (rs != null) {            

            // =================================================================
            //                     TRANSLATION SECTION
            // =================================================================
            // Before setting the Display and Return values for the control,
            // we must first build a MocaResult with the translation results.
            // This is done to avoid handling the same logic over and over 
            // in the following sections.  By having a MocaResult with the
            // required translation, then is just a matter of referencing
            // the correct MocaResult object.
            MocaResults rsTrnsl = getTranslatedMocaRs(rs);
            
            // =================================================================
            //                     DISPLAY SECTION
            // =================================================================
            // Determine the list of fields to be concatenated and displayed.
            LinkedList<String> dspFields = getDspFields();

            // NOTE: this logic is not yet complete to support full MCS 
            // functionality. The logic is only emulating what old MTF was
            // doing. That means that only first 2 columns are going to be
            // displayed on the terminal screen.
            if (dspFields.isEmpty()) {
                for (int i = 0; i < 2; i++) {
                    if (rs.getColumnCount() > i) {
                        dspFields.add(rs.getColumnName(i));
                    }
                }
            }
            
            // Need to make both calls to getDisplayText().
            // One will get the display base values.
            // The other one will get any necessary translations.
            // The values are use for the F12 display switching.
            StringBuffer[] tsDspText = getDisplayText(dspFields, rs);
            StringBuffer[] tsTranslationText = getDisplayText(dspFields, 
                rsTrnsl);
            
            // =================================================================
            //               RETURN VALUE TO THE FIELD SECTION
            // =================================================================
            int rowCount = rs.getRowCount();
            StringBuilder[] retVal = new StringBuilder[rowCount];
            
            for (int i = 0; i < retVal.length; i++) {
                retVal[i] = new StringBuilder();
            }
            
            LinkedList<String> retList = getRetFields();
            
            // If the return list is empty, then let's use the field that
            // has the same widget identifier (i.e. var_nam) as the column
            // found in the passed in MocaResults.
            if (retList.isEmpty()) {
                if (rs.containsColumn(returnField)){
                    retList.add(returnField);
                }
            }
            
            // Construct the return value for the item
            // If multiple values are returned, they will 
            // be separated by a pipe (|).
            for (String retField : retList) {
                
                // If the return field is also used for display
                // we will use the display as the return value.
                // For doing this, we use rsTemp as a switching
                // reference between both result sets.
                MocaResults rsTemp =
                    dspFields.contains(retField)? rsTrnsl : rs;
                
                rsTemp.reset();
                
                for (int r = 0; rsTemp.next(); r++) {
                    
                    String value = "|";
                    if (!rsTemp.isNull(retField)) {
                        value = rsTemp.getString(retField) + "|";
                    }
                    
                    retVal[r].append(value);
                }
            }
            
            // Remove the last pipe | from the results
            for (int r = 0; r < rowCount; r++) {
                int lastChar = retVal[r].length() - 1;
                if (lastChar > 0 && retVal[r].charAt(lastChar) == '|') {
                    retVal[r].deleteCharAt(lastChar);
                }
            }

            // =================================================================
            //                 ADD ITEMS TO THE LIST SECTION
            // =================================================================
            for (int r = 0; r < rowCount; r++) {
                addItem(tsDspText[r].toString(), 
                    tsTranslationText[r].toString(), retVal[r].toString());
            }
            
            // OK. Now, let's try to select a default item in the list as 
            // specified by les_var_def.
            if (!getItems().isEmpty()) {
                setVariableDefault();
            }
                                   
            // Lastly, we need to emulate the behavior of the old MTF by 
            // clearing return fields list because items were already added.
            retFields.clear();
        }
    }

    /**
     * Translates the contents of the passed in MocaResults object.
     * 
     * @param rs - result set to translate
     * @return translated result set
     */
    private MocaResults getTranslatedMocaRs(MocaResults rs) {
        // Create the translation result set by cloning the original's structure
        // and build a list of the fields.
        EditableResults rsTrnsl = new SimpleResults();
        List<String> rsFields = new LinkedList<String>();
        
        for (int c = 0; c < rs.getColumnCount(); c++) {
            rsTrnsl.addColumn(rs.getColumnName(c), rs.getColumnType(c));
            rsFields.add(rs.getColumnName(c));
        }
        for (int r = 0; r < rs.getRowCount(); r++) {
            rsTrnsl.addRow();
        }
        rsTrnsl.reset();

        // Read the VarConfig for each of the fields
        // to see if translation is needed for any of them.
        Map<String, CVarConfig> rsFieldsVarCfg = null;
        rsFieldsVarCfg = getFieldsVarConfig(rsFields);

        // Get the values that will be used for translation
        // filled into the new MocaResults.
        // Traverse all values (rows) for a field first.
        for (int c = 0; c < rs.getColumnCount(); c++) {

            // Initialize current field's information
            String fldNam = rs.getColumnName(c);
            CVarConfig currFldVarCfg = null;
            ITranslation trnslConfig = null;

            if (rsFieldsVarCfg != null && rsFieldsVarCfg.containsKey(fldNam)) {
                currFldVarCfg = rsFieldsVarCfg.get(fldNam);

                // If the current field uses translation control,
                // get the relevant translation control for it.
                if (currFldVarCfg != null) {
                    IForm frm = getBaseForm(this);

                    // Create the translation control.
                    trnslConfig = 
                        CTranslationProvider
                            .createTranslationCfg(currFldVarCfg, frm);

                    // DISPLAY ITEM translation control:
                    // Notice that we DON'T BIND the controls for TextSelection.
                    // The TextSelection display fields are dynamically
                    // generated.
                    // So the same control might have different fields depending
                    // on the context that this control is being used.
                    //
                    // For example the Lookup form might display different
                    // fields.
                    // Sometime it shows item number and other invoices. This
                    // results in having to handle a configuration that changes
                    // base on the control context.
                }
            }

            // Traverse through all the values of the field
            // and get the text to be display for it's value
            rs.reset();
            rsTrnsl.reset();
            
            for (int r = 0; r < rs.getRowCount(); r++) {
                // keep result rows in sync and move to next row pointer
                rs.next();
                rsTrnsl.next();
                String dspText = "";
                
                if (!rs.isNull(fldNam)) {
                    dspText = rs.getString(fldNam);

                    // Check if we need to perform translation over
                    // the field's value or we can just use the existing one.
                    if (trnslConfig != null) {
                        dspText = getTranslationValue(fldNam, rs, trnslConfig);
                    }
                }
                // assign the translation text value to the cell
                // only if the field is of type String;
                // else assign the original value.
                rsTrnsl.setValue(c,
                    rsTrnsl.getColumnType(c) == MocaType.STRING ? dspText : rs
                        .getValue(c));
            }
        }

        // return the translated result set
        return rsTrnsl;
    }

    /**
     * Construct the text that will be displayed in the terminal from the MOCA
     * result set.
     * 
     * @parm dspFields - list of fields to be displayed
     * 
     * @param rs - data source of the CDDATextSelection
     * 
     * @return StringBuffer[] One StringBuffer for each row that will be
     *         displayed in the terminal
     */
    private StringBuffer[] getDisplayText(LinkedList<String> dspFields,
            MocaResults rs) {
        int rowCount = rs.getRowCount();
        StringBuffer[] tsDspText = new StringBuffer[rowCount];
        
        for (int r = 0; r < rowCount; r++) {
            tsDspText[r] = new StringBuffer();
        }
        
        // For each display field, 
        // concatenate and pad the final display string.
        boolean spaceFlag = false;
        
        for (String fldNam : dspFields) {
            // Get the padding length for the display value
            int dspPadLength = 
                getPaddingLength(rs, fldNam, spaceFlag);

            // Concatenate current field with the previous stored displayed 
            // string and use the calculated padding to append to the 
            // new string.                
            rs.reset();
            int dspDoubleWideCharCount = 0;
            
            for (int row = 0; rs.next(); row++) {
                String dspValue = "";
                
                if (!rs.isNull(fldNam)) {
                    dspValue = rs.getValue(fldNam).toString();
                }
                
                if (spaceFlag) {
                    dspValue = spacing + dspValue;
                }
                
                dspDoubleWideCharCount = 
                    CMtfUtil.getDoubleWideCharCount(dspValue);
 
                if (dspDoubleWideCharCount + dspValue.length() < dspPadLength) {
                    // This is a scenario when we can freely render the 
                    // string on the screen even if double-wide char(s) 
                    // are found because the total display width is 
                    // not being exceeded.
                    tsDspText[row].append(StringUtils.rightPad(dspValue,
                            (dspPadLength - dspDoubleWideCharCount)));
                }
                else {
                    // Here, since the render-string contains double wide
                    // chars, we have to check each individual character 
                    // that make up the render-string to find out what we 
                    // can fit to render on the screen.
                    StringBuffer tempVal = new StringBuffer();
                    int totalColWidth = 0;
                    int extraColumnsConsumed = 0;
                    boolean isLastCharDoubleWide = false;
                    char[] charsToRender = dspValue.toCharArray();

                    // Loop on each individual character in the array.

                    for (int i = 0; i < charsToRender.length; i++) {
                        char c = charsToRender[i];

                        // Check if the current character is double-wide and
                        // increment the count of terminal columns needed to
                        // paint this character on the display screen.
                        if (CMtfUtil.isDoubleWideChar((int) c)) {
                            isLastCharDoubleWide = true;
                            ++extraColumnsConsumed;
                            totalColWidth = totalColWidth + 2;
                        }
                        else {
                            isLastCharDoubleWide = false;
                            ++totalColWidth;
                        }
                        if (totalColWidth >= dspPadLength) {
                            // OK, we have reached the maximum allowed width
                            // of render value that can paint on the screen.
                            // Let's reset the render value and get out of 
                            // the loop.

                            if (totalColWidth == dspPadLength) {
                                // Here, either initial field refresh is in
                                // progress or an existing character 
                                // in buffer has been replaced. 
                                // Thus, let's render the whole string.
                                tsDspText[row].append(tempVal.append(c));
                            }
                            else if (isLastCharDoubleWide) {
                                tsDspText[row].append(StringUtils.rightPad(
                                    tempVal.toString(), dspPadLength 
                                        - extraColumnsConsumed));

                                if (CMtfUtil.getDisplayColumnCount(
                                    tsDspText[row].toString(), tsDspText[row]
                                        .length()) < dspPadLength) {
                                    // OK, this is a special case where we
                                    // need to append one more space 
                                    // to the render-string.                                        
                                    tsDspText[row].append(" ");
                                }
                            }
                            else {
                                tsDspText[row].append(tempVal.append(" "));
                            }

                            // Get out of this loop - we got our render
                            // string!
                            break;
                        }
                        else {
                            // Concatenate the temporary value to store the
                            // final render string
                            // that can fit onto the screen.
                            tempVal = tempVal.append(c);
                        }
                    }
                }
            }
            spaceFlag = true;
        }
        return tsDspText;
    }

    private Map<String, CVarConfig> getFieldsVarConfig(List<String> dspList) {
        IForm frm = getBaseForm(this);
        CMcsFormConfig mcsConfig = frm.getMcsFormConfig();

        // These variables will track what is cache and what's not.
        //   dspFldVarConfig - fields & VarConfigs to be returned
        //   nonCacheFields - fields which we need to re-try fill cache
        Map<String, CVarConfig> dspFldVarConfig = 
            new HashMap<String, CVarConfig>();
        List<String> nonCacheFields = new LinkedList<String>();
        
        // Let's try getting the VarConfig from EXISTING cache...
        // Any field that is not cached yet, we will try 
        // filling the cache for it and re-fetch it. 
        Iterator<String> it = dspList.iterator();
        while (it.hasNext()) {
            String curFld = it.next();
            CVarConfig tmpConfig = mcsConfig.getVarConfig(curFld);
            
            if (tmpConfig != null) {
                dspFldVarConfig.put(curFld, tmpConfig);
            }
            else {
                nonCacheFields.add(curFld);
            }
        }

        // Build a CSV list of non-cache fields 
        StringBuffer cacheNewFields = new StringBuffer("");
        for (String fld : nonCacheFields) {
            cacheNewFields.append("'" + fld + "',");
        }
        // remove the last comma.
        if (cacheNewFields.toString().endsWith(",")) {
            cacheNewFields.deleteCharAt(cacheNewFields.length() - 1);
        }

        // Try filling the cache for the fields that miss cache.
        if (cacheNewFields.length() > 0) {
            mcsConfig.fillVarConfigCache(frm.getIdentifier(), 
                cacheNewFields.toString());
        }
        
        // Retry getting from cache any NEW CACHED field.
        Iterator<String> itr = nonCacheFields.iterator();
        while (itr.hasNext()) {
            String curFld = itr.next();
            CVarConfig tmpConfig = mcsConfig.getVarConfig(curFld);
            
            if (tmpConfig != null) {
                dspFldVarConfig.put(curFld, tmpConfig);
                itr.remove();
            }
        }
        
        // Any remaining non-cache field means there is no 
        // variable configuration defined in the system.
        // For this reason we will create a dummy VarConfig
        // which will prevent re-query the dB for a none
        // existent configuration in the future.
        for (String fld : nonCacheFields) {
            CVarConfig dummyVarCfg = 
                new CVarConfig(MtfConstants.DEFAULT_VARCFG_VISIBLE, 
                               MtfConstants.DEFAULT_VARCFG_ENABLE,
                               MtfConstants.DEFAULT_VARCFG_WIDTH, 
                               MtfConstants.DEFAULT_VARCFG_CTLPROP,
                               MtfConstants.DEFAULT_VARCFG_FLDTYP);
            dummyVarCfg.setPlaceHolder(true);
            mcsConfig.putVarConfig(fld, dummyVarCfg);
            dspFldVarConfig.put(fld, dummyVarCfg);
        }
        
        return dspFldVarConfig;
    }
    
    /**
     * Calculate the pad length needed for the text to display.
     * @param rs - results from which to find padding length
     * @param fieldname - field for which to find the padding length
     * @param spaceFlag - consider spacing into the padding
     * @return
     */
    private int getPaddingLength(MocaResults rs,
                                 String fieldname,
                                 boolean spaceFlag) {
        int padLength = 0;
        int textLength = 0;

        // exit if the result doesn't contain the field name.
        if (!rs.containsColumn(fieldname)) {
            return 0;
        }

        // reset and recurse all the results to
        // find the longest string value and pad to it's size
        rs.reset();
        while (rs.next()) {
            textLength = 
                !rs.isNull(fieldname)? 
                    rs.getValue(fieldname).toString().length() : 0;
            textLength += spaceFlag? spacing.length() : 0;
            
            // this value is the longest
            if (textLength > padLength) {
                padLength = textLength;
            }
        } 
        
        // returns the longest padLength for field
        return padLength;
    }

    
    public int getSelectionPadding() {
        return cchSelectionPadding;
    }

    public void setSelectionPadding(int _cchSelectionPadding) {
        cchSelectionPadding = _cchSelectionPadding;
    }
    
    public boolean isCompact() {
        return fCompact;
    }

    public void setCompact(boolean _fCompact) {
        fCompact = _fCompact;
        setRefreshRequired(true);
    }

    public LinkedList<String> getRetFields() {
        return retFields;
    }

    public void setRetFields(String csvFields) {
        log.trace("Text Selection (" + getUniqueId() + ")" 
            + " - Return Fields = [" + csvFields + "]");
        
        // Split the comma separated list
        String[] lstFields = csvFields.split(",");
        
        // clear current return fields 
        // to be overwritten by the new ones
        retFields.clear();
        for (String var : lstFields) {
            retFields.add(var);
        }
    }
    
    /**
     * Toggle between displaying the base or translation value
     * for the text painted in the screen.
     */
    public void toggleDisplayValue() {
        setRefreshRequired(true);
        refresh();    
    }

    /**
     * This method will try to get the value of a field 
     * and translate it to the display value.
     * 
     * @param fieldName - the field waiting for translation
     * @param rs - current record in the MocaResults to translate
     * @param trnslCfg - translation configuration to use
     * @return display value
     */
    private String getTranslationValue(String fieldName, 
                                       MocaResults rs,
                                       ITranslation trnslCfg) {
        // By default return the expected base value
        String translationValue = 
            !rs.isNull(fieldName)? rs.getString(fieldName) : "";

        // Perform translation with the corresponding control.
        if (trnslCfg != null) {
            CTranslationResult trnslRes = null;
            
            // Display Item - translation control
            if (trnslCfg instanceof CDisplayItem) {
                CDisplayItem dspItmCfg = 
                    (CDisplayItem) trnslCfg;
                
                trnslRes  = dspItmCfg.getTranslation(fieldName, rs);
            }
            // default translation handler
            else {
                trnslRes = trnslCfg.getTranslation(translationValue);
            }
            
            // set the translation value result
            translationValue = trnslRes.getTranslation();
        }   
        
        // return translation result
        return translationValue;
    }
    
    public LinkedList<String> getDspFields() {
        return dspFields;
    }

    public void setDspFields(String csvFields) {
        log.trace("Text Selection (" + getUniqueId() + ")" 
            + " - Display Fields = [" + csvFields + "]");
        
        // Split the comma separated list
        String[] lstFields = csvFields.split(",");
        
        dspFields.clear();
        for (String var : lstFields) {
            dspFields.add(var);
        }
    }
    
    public boolean isShowMarkers() {
        return showMarkers;
    }

    public void setShowMarkers(boolean showMarkers) {
        this.showMarkers = showMarkers;
        
        if (showMarkers) {
            markerRows = 2;
        }
        else {
            markerRows = 0;
        }
    }
    
    public boolean isShowSelection() {
        return showSelection;
    }

    public void setShowSelection(boolean showSelection) {
        this.showSelection = showSelection;
    }
    
    public boolean isCircularNavigation() {
        return circularNavigation;
    }

    public void setCircularNavigation(boolean circularNavigation) {
        this.circularNavigation = circularNavigation;
    }
    
    public void clear() {
        getItems().clear();        
        dspFields.clear();
        retFields.clear();
        
        // List is empty so reset display rows.
        if (autoRows) {
            cDisplayRows = -1;
        }

        idxSelected = -1;
    }

    /**
     * Queries the length of the widget's text value.
     * <p>
     * This method is provided for convenience, as the same value may be
     * obtained by querying the length of the string returned by
     * {@link #getText()}.
     * </p>
     * 
     * @return Length of the text value
     * @see com.redprairie.mtf.foundation.presentation.ITextWidget#getLength()
     */
    public int getLength() {
        if (idxSelected != -1) {
            ItemData item = getItems().get(idxSelected);
            if (getBaseForm(this).isTranslationDisplayed()) {
                return item.getTranslatedDisplay().length();
            }
            else {
                return item.getDisplay().length();
            }
        }
        return 0;
    }
    
    public int getWidth() {

        if (cchDisplayCols < 0) {
            int cchDesiredDisplay = 2;

            for (int i=0; i < getItems().size(); i++) {
                String strItem = getDisplayString(i);

                if (strItem != null) {
                    cchDesiredDisplay = Math.max(cchDesiredDisplay, 
                        strItem.length() + 2);
                }
            }
            cchDisplayCols = Math.min(cchDesiredDisplay,
                ((CDisplay) getDisplay()).getWidth() - getAbsoluteColumn());
        }
        return cchDisplayCols;
    }

    public int getHeight() {

        if (_fIamSizing) {
            return 0;
        }

        if (cDisplayRows < 0) {

            if (!fCompact) {
                _fIamSizing = true;
                int cItems = getItems().size();

                if (cItems < 1) {
                    cDisplayRows = markerRows;
                }
                else {
                    AContainer container = (AContainer) getContainer();
                    boolean fFound = false;

                    while (!fFound) {
                        container = (AContainer) container.getContainer();
                        if (container instanceof IForm) {
                            fFound = true;
                        }
                    }
                    cDisplayRows = Math.min(((CDisplay) getDisplay())
                        .getHeight() - container.getHeight(), 
                        (cItems * lines) + markerRows);

                }
                _fIamSizing = false;
            }
            else {
                cDisplayRows = 1;
            }
        }
        return cDisplayRows;
    }

    public void refresh() {

        if (!isRefreshRequired()) {
            return;
        }

        int selectedListRow = getSelectedIndex();
        if (selectedListRow < 0) {
            selectedListRow = 0;
        }
        
        refreshListDisplay(selectedListRow, null);
        setRefreshRequired(false);
    }
    
    /**
     * Refresh the list display. Redraw all the rows that are visible and
     * highlight the currently selected row. By default, highlighting of items
     * in the text selection object should be enabled. However, highlighting of
     * items in the text selection object can be controlled (i.e.
     * enabled/disabled) by the setting the disable_item_list_highlight=true
     * property via ctrl_prop column on les_var_config table.
     * 
     * @param selectedListRow index of row we should treat as currently selected
     * @param strbufTypeAheadMatches
     */
    private void refreshListDisplay(
            int selectedListRow, StringBuffer strbufTypeAheadMatches) {
        
        ((CDisplay) getDisplay()).lockTerminal();
        
        try {
            ITerminalDriver tio = ((CDisplay) getDisplay()).getTerminal();
            tio.storeCursor();
            
            // ------ Refresh selection list
            int firstListRowToDisplay = computeFirstListRowToDisplay(selectedListRow);
            refreshSelection(firstListRowToDisplay, strbufTypeAheadMatches);
    
            if (selectedListRow < getItems().size()) {
                
                // ------ Refresh "cursor" row
                int selectedDisplayRow = computeSelectedDisplayRow(selectedListRow);
                
                // By default, highlighting of items in the text selection
                // object should be enabled.
                boolean isItemHighlightEnabled = true;
                
                // The highlighting of items in the text selection object can
                // be controlled (i.e. enabled/disabled) by the setting the
                // appropriate property via ctrl_prop column on les_var_config
                // table. This is sometimes desirable for screen refresh
                // performance when an item spans across most of the terminal
                // screen (e.g. Receipt Display form). With that being said,
                // let's check if highlighting should be displayed for this
                // object...
                IForm frm = getBaseForm(this);
                CMcsFormConfig mcsCfg = frm.getMcsFormConfig();
                CVarConfig varCfg = mcsCfg.getVarConfig(this.getIdentifier());
                
                if (varCfg != null) {
                    // Parse the value of the disable highlight property.
                    String propertyValue = varCfg.getCtrlPropValue(
                        MtfConstants.CTRL_PROP_DISABLE_ITEM_LIST_HIGHLIGHT);
                    
                    if (propertyValue != null
                            && propertyValue.equalsIgnoreCase("true")) {
                        isItemHighlightEnabled = false;
                    }
                }
                
                if (isItemHighlightEnabled) {
                    renderRow(selectedListRow, selectedDisplayRow, tio,
                        isItemHighlightEnabled);
                }
            }
            
            tio.restoreCursor();
            tio.flush();
        }
        catch (MtfInterruptedException e) {
            // We need to re-throw this exception to make sure that it is
            // not trapped by the catch (Exception) below.
            throw e;
        }
        catch (Exception e) {
            log.error("An unexpected exception occurred while performing the "
                + "refresh of text selection widget display [" + 
                this.getUniqueId() + "]", e);
        }
        finally {
            ((CDisplay) getDisplay()).unlockTerminal();
        }
    }
    
    /**
     * Compute the maximum number of list rows that can be 
     * displayed on the screen at one time
     * 
     * @return
     */
    private int computeMaxDisplayRows() {
        return (fCompact) ? 1 : (getHeight() - markerRows) / lines;
    }
    
    /**
     * Compute the first row that should be displayed based on
     * the current row that is selected, the entire length of the 
     * list and the number of rows that are displayed at a time
     * 
     * @param selectedListRow index of row we should treat as currently selected
     * @return index of first list row that should be displayed
     */
    private int computeFirstListRowToDisplay(int selectedListRow) {
    
        // The default is to display the first row 
        // if we have less than one full screen of items
        int maxDisplayRows = computeMaxDisplayRows();
        /* If we scroll down and select an item and return
         * to the lookup form then we need to set the cursor
         * to the top of the page.
         */
        if (selectedListRow == 0 && scrollMode == 1) {
            scrollMode = 0;
        }
        if (scrollMode == SCROLL_MODE_DOWN) {
            if (selectedListRow >= maxDisplayRows + currentDisplayTop) {
                // We have scrolled down beyond the first screen
                currentDisplayTop = selectedListRow - maxDisplayRows + 1;
            }
            else if (selectedListRow == 0) {
                /* If there is no selected List row then set the
                 * default to display the first row.
                 */
                currentDisplayTop = 0;
            }
        }
        else if (scrollMode == SCROLL_MODE_UP) {
            int rowsInList = getItems().size();
            // We have more than one full screen of rows
            if (rowsInList > maxDisplayRows) {
                if (selectedListRow >= maxDisplayRows + currentDisplayTop) {
                    // We have scrolled up present page the previous page.
                    currentDisplayTop = selectedListRow + maxDisplayRows - 1;
                }
                else if (selectedListRow <= currentDisplayTop) {
                    /* If we are not in the first page and not selecting 
                     * previous item and if we scroll down/up and
                     * select an item and return to the lookup form then
                     * we need to set the cursor to the top of the page.
                     */
                    currentDisplayTop = selectedListRow;
                }
                else if (scrollUpMode != 1 && selectedListRow >= 0
                         && selectedListRow <= 4) {
                    /* If we are in the first page and not selecting 
                     * previous item and if we scroll down/up and
                     * select an item and return to the lookup form then
                     * we need to set the cursor to the top of the page.
                     */
                    currentDisplayTop = selectedListRow;
                }
            }
            else if (selectedListRow == 0) {
                /* If there is no selected List row then set the
                 * default to display the first row.
                 */
                currentDisplayTop = 0;
            }
        }
        
        return currentDisplayTop;
    }
    
    /**
     * Compute the display row for the currently 
     * selected list row
     * 
     * @param selectedListRow index of row we should treat as currently selected
     * @return display row used to display the supplied selected list row
     */
    private int computeSelectedDisplayRow(int selectedListRow) {
        
        int firstListRowToDisplay = computeFirstListRowToDisplay(selectedListRow);
        
        int selectedDisplayRow = getAbsoluteRow()
            + ((selectedListRow - firstListRowToDisplay) * lines)
            + ((fCompact || !showMarkers) ? 0 : 1);
        
        return selectedDisplayRow;
    }

    /**
     * Display the list of rows starting with the provided index
     * 
     * @param listRow the first row of the list to display
     */
    protected void refreshSelection(
                int listRow,
                StringBuffer _strbufTypeAhead) {

        String strSeperator = StringUtils.repeat(STR_SEPERATOR, getWidth());
        String strSeperatorMoreUp = 
            StringUtils.repeat(STR_SEPERATOR_UP, getWidth());
        String strSeperatorMoreDown = 
            StringUtils.repeat(STR_SEPERATOR_DOWN, getWidth());

        try {
            ITerminalDriver tio = ((CDisplay) getDisplay()).getTerminal();
            
            int offCursorRow = getAbsoluteRow();

            // Render top separator bar.
            if (showMarkers) {
                tio.setCursor(offCursorRow++, getAbsoluteColumn());

                if (listRow > 0) {
                    tio.write(strSeperatorMoreUp);
                }
                else {
                    tio.write(strSeperator);
                }

                if ((_strbufTypeAhead != null) 
                        && (_strbufTypeAhead.length() > 0) 
                        && (getWidth() > 4)) {

                    int cchMaxTypeAheadDisplay = getWidth() - 4;

                    tio.setCursor(offCursorRow - 1, getAbsoluteColumn());

                    tio.write(Character.toString(CH_LEFT_TYPEAHEAD_BRACKET));
                    tio.write(_strbufTypeAhead.substring(0, 
                        Math.min(cchMaxTypeAheadDisplay, _strbufTypeAhead.length())));
                    tio.write(Character.toString(CH_RIGHT_TYPEAHEAD_BRACKET));
                }
            }

            // Loop on the items in the text selection list, and render the
            // ones that can fit on the terminal screen.
            int cRemainingItems = getItems().size() - listRow;

            int idxMax = listRow + Math.min(
                cRemainingItems, computeMaxDisplayRows());
            
            for (int idxRow = listRow; idxRow < idxMax; idxRow++) {
                offCursorRow = renderRow(idxRow, offCursorRow, tio, false);
            }

            // Render bottom separator bar.
            if (showMarkers) {
                tio.setCursor(offCursorRow, getAbsoluteColumn());
                if (idxMax < cRemainingItems) {
                    tio.write(strSeperatorMoreDown);
                }
                else {
                    tio.write(strSeperator);
                }
            }

            // Flush the terminal I/O.
            tio.flush();
        }
        catch (MtfInterruptedException e) {
            // We need to re-throw this exception to make sure that it is
            // not trapped by the catch (Exception) below.
            throw e;
        }
        catch (Exception e) {
            log.error("An unexpected exception occurred while performing the "
                + "refresh of text selection widget [" + this.getUniqueId()
                + "]", e);
        }
    }
    
    /**
     * Render one list row on the screen.  May consume multiple
     * rows on the screen if each list row spans multiple display rows
     * 
     * @param listRow row in list to display
     * @param displayRow row in display to write output
     * @param tio Terminal Driver
     * @param reverseVideo true if the background needs to be inverted
     * @return the next available row 
     */
    private int renderRow(
            int listRow, int displayRow, 
            ITerminalDriver tio, boolean reverseVideo) {
        
        if (lines > 1) {
            // May take more than one line to display each row of the list
            
            // Get the string to be rendered on the screen.
            String stringToRender = getDisplayString(listRow);

            // If this is a Right-To-Left oriented string we will need to 
            // reorder the text so that it will set up the string format 
            // correctly. The resulting string will reorder the text so 
            // that it is arranged in a more logical fashion.
            if (isRTL) {
                stringToRender = stringToRender.trim();
            }

            // Calculate the size of the string to be rendered and also 
            // the maximum number of characters that can be rendered on 
            // the terminal screen.
            int renderStrWidth = 0;
            int maxDisplaySize = lines * getWidth();
            
            if (stringToRender != null && !stringToRender.isEmpty()) {
                renderStrWidth = stringToRender.length();
                
                if (renderStrWidth > maxDisplaySize) {
                    stringToRender = stringToRender.substring(
                        0, maxDisplaySize);
                }
            }
       
            // Add additional blank spaces to the end of the
            // string if the maximum size of characters for two
            // lines has not been achieved. Before we add extra
            // space, make sure that we account for any double
            // wide characters found in the render string.
            int doubleWideCharCount = 
                CMtfUtil.getDoubleWideCharCount(stringToRender);
            stringToRender = StringUtils.rightPad(stringToRender,
                maxDisplaySize - doubleWideCharCount, ' ');
            
            // Break up the string to be rendered into individual
            // characters to be written on the screen.
            char[] charsToRender = stringToRender.toCharArray();
            
            // Specify the row and column coordinates.
            int displayCol = 0;
            int rtlMaxCol = 0;

            // Here we are setting up our column position. If
            // the string is RTL, the text needs to be written
            // starting from the right side of the screen.
            // Otherwise, we can position it on the left.
            if (isRTL) {
                displayCol = getAbsoluteColumn() + getWidth() - 1;
                rtlMaxCol = getAbsoluteColumn();
            }
            else {
                displayCol = getAbsoluteColumn();
            }
            
            // Saves the length of the string, We have to do this here 
            // because in the next step, if our item is RTL then
            // we want to trim off the padding, but still keep
            // the size of the box for loop iteration . We need  
            // to do this because there are very specific  
            // instances where the padding would be thrown off. 
            int strLength = charsToRender.length;
            
            if (isRTL) {
                charsToRender = stringToRender.trim().toCharArray();
            }
            
            // If we don't have any double wide characters to consider, and we
            // are in a left-to-right locale. Then we don't have to worry about
            // printing each line character by character.
            if (!CMtfUtil.containsDoubleWideChar(stringToRender.trim()) 
                    && !isRTL) {
                
                // Split the string into substrings based on the width of the 
                // screen.
                ArrayList<String> subStrings = new ArrayList<String>();
                String parsedString = stringToRender;
                
                while (parsedString.length() > getWidth()) {
                    subStrings.add(parsedString.substring(0, getWidth()));
                    parsedString = parsedString.substring(getWidth());
                    
                }
                
                // Add the last row. 
                if (!parsedString.isEmpty()) {
                    subStrings.add(parsedString);
                }
                
                Iterator<String> iter = subStrings.iterator();
                
                // Iterate through the lines, and print each one.  
                while (iter.hasNext()) {
                    
                    String currentRowText = iter.next();
                    
                    // Invert the background. 
                    if (reverseVideo) {
                        tio.inverseBackground();
                    }
                    else {
                        tio.resetBackground();
                    }
                    
                    // Render screen for the trace. 
                    captureRenderedText(displayRow, displayCol, currentRowText);
                    
                    // Place the cursor per our calculated coordinates.
                    tio.setCursor(displayRow, displayCol);
                    
                    tio.eraseToEndOfLine();
                    
                    tio.write(currentRowText);
                    
                    // As long as there is another row to print, move the cursor
                    // down.
                    if (iter.hasNext()) {
                        displayRow++;
                        displayCol = getAbsoluteColumn();
                    }
                }
            }
            else {
                for (int i = 0; i < strLength; i++) {
                    
                    if (reverseVideo) {
                        tio.inverseBackground();
                    }
                    else {
                        tio.resetBackground();
                    }
                    
                    if ((!isRTL) && displayCol > getWidth()) {
                        
                        // Let's move to the next row and initial column.
                        displayRow++;
                        displayCol = getAbsoluteColumn();
                    }
                    else if (isRTL && displayCol < rtlMaxCol) {
                        
                        // Let's move to the next row and initial column.
                        displayRow++;
                        displayCol = getAbsoluteColumn() + getWidth() - 1;
                    }
                    
                    // Capture the rendered text in the form matrix
                    if (i < charsToRender.length) {
                        captureRenderedText(displayRow, displayCol, 
                            Character.toString(charsToRender[i]));
                    }
    
                    // Place the cursor per our calculated
                    // coordinates.
                    tio.setCursor(displayRow, displayCol);
    
                    // Before rendering the item's text on the
                    // screen,
                    // let's first erase the whole terminal row to
                    // start out clean.
                    if (!isRTL) {
                        tio.eraseToEndOfLine();
                    }
                    
                    // Write the character to the terminal screen.
                    if (isRTL) {
                        
                        // This is where we add the padding in, if it gets 
                        // inside here, it means our string has printed all it's
                        // characters, and all that is left are adding  the 
                        //  spaces to fill out the form.
                        if (i >= charsToRender.length) {
                            tio.write(' ');
                            displayCol--;
                        }
                        
                        // If the current character is RTL, or a 
                        // space, print it.
                        else if (BidiUtils.isRightToLeftChar(charsToRender[i])
                                || charsToRender[i] == ' ') {
                            tio.write(Character.toString(charsToRender[i]));
                            displayCol--;
                        }
                        
                        // This takes care of the case that some 
                        // Left-To-Right Text has been reached. 
                        else {
                            
                            // determine exactly how long the LTR 
                            // text happens to be.
                            int lastPos = i;
                            
                            while (lastPos < charsToRender.length
                                    && !BidiUtils.isRightToLeftChar(
                                        charsToRender[lastPos])
                                    && lastPos - i < displayCol) {
                                
                                lastPos++;
                            }
                            
                            int frontPadding = 0;
                            
                            for (int j = 0; j < lastPos - i; j++) {
                                
                                // If our text is LTR, we need to handle any 
                                // spaces that occur after the word. This won't
                                // be picked up otherwise. Since we are doing a 
                                // character by character print out, we need to 
                                // be able to handle this.
                                if (charsToRender[lastPos - j - 1] == ' '
                                        && BidiUtils.containsRightToLeftChar(
                                            stringToRender)) {
                                    frontPadding++;
                                }
                                else {
                                    tio.write(Character.toString(
                                        charsToRender[lastPos - 1 - j]));
                                    
                                    if (reverseVideo) {
                                        tio.inverseBackground();
                                    }
                                    else {
                                        tio.resetBackground();
                                    }
                                    
                                    // Check if the current character is 
                                    // double-wide and increment the count of
                                    // terminal columns needed to paint this 
                                    // character on the display screen.
                                    if (CMtfUtil.isDoubleWideChar(
                                            charsToRender[i])) {
                                        displayCol -= 2;
                                    }
                                    else {
                                        displayCol--;
                                    }
                                    tio.setCursor(displayRow, displayCol);
                                }
                            }
                            
                            for (int j = 0; j < frontPadding; j++) {
                                
                                tio.write(' ');
                                displayCol--;
                                tio.setCursor(displayRow, displayCol);
                            }
                            i = lastPos - 1;
                        }
                    }
                    else {
                        // Not RTL
                        tio.write(Character.toString(charsToRender[i]));
                        
                        // Check if the current character is double-wide and
                        // increment the count of terminal columns needed to
                        // paint this character on the display screen.
                        if (CMtfUtil.isDoubleWideChar(charsToRender[i])) {
                            displayCol += 2;
                        }
                        else {
                            displayCol++;
                        }
                    }
                }
            }
        }
        else {
            // One line of the display will be used for each row of the list
            
            StringBuffer sbufRenderItem = new StringBuffer(getWidth());

            if (showSelection) {
                if (listRow == getSelectedIndex()) {
                    sbufRenderItem.append(CH_LEFT_BRACKET);
                }
                else {
                    sbufRenderItem.append(' ');
                }
            }

            sbufRenderItem.append(StringUtils.rightPad(
                getDisplayString(listRow),
                getWidth() - ((showSelection) ? 2 : 0), ' ').substring(0,
                    getWidth() - ((showSelection) ? 2 : 0)));

            if (showSelection) {
                if (listRow == getSelectedIndex()) {
                    sbufRenderItem.append(CH_RIGHT_BRACKET);
                }
                else {
                    sbufRenderItem.append(' ');
                }
            }
            
            if (reverseVideo) {
                tio.inverseBackground();
            }
            else {
                tio.resetBackground();
            }
            
            // Specify the row and column coordinates.
            int displayCol = 0;
            
            // If it's RTL, we need to paint it character by 
            // character in order to handle the padding. 
            if (isRTL) {
                displayCol = getAbsoluteColumn() + getWidth() - 1;
                String stringToRender = sbufRenderItem.toString();
                stringToRender = stringToRender.trim();
                char[] charsToRender = stringToRender.toCharArray();

                for (int i = 0; i < getWidth(); i--) {
                    
                    // This is where we add the padding in, if it gets inside 
                    // here, it means our string has printed all it's 
                    // characters, and all that is left are adding the spaces 
                    // to print out the form.
                    if (i >= charsToRender.length) {
                        tio.write(' ');
                        displayCol--;
                    }
                    
                    // If the current character is RTL, or a 
                    // space, print it.
                    else if (BidiUtils.isRightToLeftChar(charsToRender[i])
                            || charsToRender[i] == ' ') {
                        tio.write(Character.toString(charsToRender[i]));
                        displayCol--;
                    }
                    
                    // This takes care of the case that some 
                    // Left-To-Right Text has been reached. 
                    else {
                        
                        // determine exactly how long the LTR 
                        // text happens to be.
                        int lastPos = i;
                        
                        while (lastPos < charsToRender.length
                                && !BidiUtils.isRightToLeftChar(
                                        charsToRender[lastPos])
                                && lastPos - i < displayCol) {
                            
                            lastPos++;
                        }
                        
                        int frontPadding = 0;
                        
                        for (int j = 0; j < lastPos - i; j++) {
                            
                            // If our text is LTR, we need to handle any 
                            // spaces that occur after the word. This won't be 
                            // picked up otherwise. Since we are doing a 
                            // character by character print out, we need to 
                            // be able to handle this.
                            if (charsToRender[lastPos - j - 1] == ' '
                                    && BidiUtils
                                        .containsRightToLeftChar(
                                            stringToRender)) {
                                frontPadding++;
                            }
                            else {
                                tio.write(Character.toString(
                                    charsToRender[lastPos - 1 - j]));
                                
                                if (reverseVideo) {
                                    tio.inverseBackground();
                                }
                                else {
                                    tio.resetBackground();
                                }
                                
                                // Check if the current character is 
                                // double-wide and increment the count of
                                // terminal columns needed to paint this 
                                // character on the display screen.
                                if (CMtfUtil.isDoubleWideChar(
                                        charsToRender[i])) {
                                    displayCol -= 2;
                                }
                                else {
                                    displayCol--;
                                }
                                tio.setCursor(displayRow, displayCol);
                            }
                        }
                        
                        for (int j = 0; j < frontPadding; j++) {
                            
                            tio.write(' ');
                            displayCol--;
                            tio.setCursor(displayRow, displayCol);
                        }
                        i = lastPos - 1;
                    }
                }
            }
            else {
                // Not RTL 
                displayCol = getAbsoluteColumn();

                // Write the text on the screen.
                tio.setCursor(displayRow, displayCol);
                tio.write(sbufRenderItem.toString());
            }
            
            // Capture the rendered text in the form matrix
            captureRenderedText(displayRow, displayCol, 
                sbufRenderItem.toString());
        }
        
        return ++displayRow;
    }

    public IVirtualKey performInteraction() throws XFormAlreadyOnStack {

        refresh();

        // Execute onFieldEntry before entering the field
        log.trace("<OnFieldEntry Action> Executing for widget - "
                + this.getIdentifier());
        if (!validatedDelegate.onFieldEntry(this)) {
            return new CVirtualKey(CVirtualKey.VKID_NONE);
        }
        else {
            // refresh all to get changes from onFieldEntry
            ((CForm) ((CDisplay) this.getDisplay()).getCurrentFormOnStack())
                .setRefreshRequired(true);

            ((CDisplay) this.getDisplay()).getCurrentFormOnStack().refresh();
        }

        // ... continue with entering the field.
        ((CDisplay) getDisplay()).lockTerminal();

        try {
            ITerminalDriver tio = ((CDisplay) getDisplay()).getTerminal();
            tio.storeCursor();

            IVirtualKey vk = null;

            int selectedListRow = getSelectedIndex();
            
            if (isDisplayGridTitle() && selectedListRow < 1) {
                selectedListRow = 1;
            }
            else if (selectedListRow < 0) {
                selectedListRow = 0;
            }

            Deque<Integer> stkidxTypeAheadMatches = new ArrayDeque<Integer>();
            StringBuffer strbufTypeAheadMatches = new StringBuffer();

            boolean fNeedRefresh = true;

            while (vk == null) {

                if (fNeedRefresh) {
                    refreshListDisplay(selectedListRow, strbufTypeAheadMatches);
                    
                    // Display the cursor in the natural position
                    int selectedDisplayRow = 
                        computeSelectedDisplayRow(selectedListRow);
                    
                    if (isRTL) {
                        tio.setCursor(selectedDisplayRow, getWidth());
                    }
                    else {
                        tio.setCursor(selectedDisplayRow,
                            getAbsoluteColumn() + (showSelection ? 1 : 0));
                    }
                    tio.flush();
                    fNeedRefresh = false;
                }

                // ------ Get user input
                CKeyEvent evtkey;

                try {
                    ((CDisplay) getDisplay()).unlockTerminal();
                    evtkey = ((CForm) ((AContainer) getContainer())
                        .getInputForm()).getKeyEvent();
                }
                finally {
                    ((CDisplay) getDisplay()).lockTerminal();
                }

                vk = evtkey.getPhysicalVirtualKey();

                if ((vk == null)
                        || vk.getVirtualKeyId().equals(IVirtualKey.VKID_SPACE)
                        || vk.getVirtualKeyId().equals(IVirtualKey.VKID_CHAR_Y)
                        || vk.getVirtualKeyId().equals(IVirtualKey.VKID_CHAR_N)) {

                    // ------ Sanity check

                    final char chToMatch = Character.toLowerCase((char) evtkey
                        .getKey());

                    if (Character.isISOControl(chToMatch)) {
                        continue;
                    }

                    // ------ Handle type-ahead

                    vk = null;
                    String strTryMatch = strbufTypeAheadMatches.toString()
                            + chToMatch;

                    // Get the display without translation...
                    // this is what the user is typing.
                    int idxMatch = selectedListRow;
                    for (Iterator<ItemData> iItem = 
                         getItems().listIterator(selectedListRow);
                         iItem.hasNext(); idxMatch++) {

                        String strItem = ((ItemData) iItem.next()).getDisplay();
                        if (strItem.toLowerCase().startsWith(strTryMatch)) {

                            stkidxTypeAheadMatches.push(Integer
                                .valueOf(idxMatch));
                            strbufTypeAheadMatches.append(chToMatch);
                            selectedListRow = idxMatch;
                            fNeedRefresh = true;
                            log.trace("Type-ahead ["
                                + strbufTypeAheadMatches.toString() + "]");
                            break;
                        }
                    }
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_TIMEOUT)) {
                    continue;
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_BS)
                        || vk.getVirtualKeyId().equals(IVirtualKey.VKID_DEL)) {

                    // ------ Handle type-ahead backstep

                    if (!stkidxTypeAheadMatches.isEmpty()) {

                        stkidxTypeAheadMatches.pop();
                        strbufTypeAheadMatches
                            .deleteCharAt(strbufTypeAheadMatches.length() - 1);

                        if (stkidxTypeAheadMatches.isEmpty()) {
                            selectedListRow = (idxSelected >= 0) ? 
                                    idxSelected : 0;
                        }
                        else {
                            selectedListRow = ((Integer) stkidxTypeAheadMatches
                                .peek()).intValue();
                        }

                        fNeedRefresh = true;
                        log.trace("Type-ahead backstep to ["
                            + strbufTypeAheadMatches.toString() + "]");
                    }
                    vk = null;
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_UP)
                        || vk.getVirtualKeyId().equals(IVirtualKey.VKID_LEFT)) {
                    /* If not selecting the previous item then
                     * set the value to 0.
                     */
                    scrollUpMode = 0;
                    CWidgetEvent ev = new CWidgetEvent(EVENT_CODE_SCROLL_UP);
                    if (!validatedDelegate.onProcessEvent(this, ev)) {
                        return CVirtualKey.VK_NONE;
                    }
                    
                    // ------ Move to previous item
                    try {
                        
                        log.trace("selectedListRow: " + selectedListRow + ", isDisplayGridTitle:" + isDisplayGridTitle);
                        
                        if ((selectedListRow > 0 && !isDisplayGridTitle()) ||
                            (selectedListRow > 1 && isDisplayGridTitle())) {
                            --selectedListRow;
                            fNeedRefresh = true;
                            vk = null;
                            scrollMode = SCROLL_MODE_UP;
                            /* If selecting the previous item then
                             * set the value to 1.
                             */
                            scrollUpMode = 1;
                        }
                        else if (circularNavigation) {
                            // Move back to the end of the list so the list is
                            // now circular
                            selectedListRow = getItems().size() - 1;
                            fNeedRefresh = true;
                            vk = null;
                            scrollMode = SCROLL_MODE_UP;
                        }

                        stkidxTypeAheadMatches.clear();
                        strbufTypeAheadMatches.setLength(0);
                        selectItem(selectedListRow);
                    }
                    catch (IndexOutOfBoundsException ex) {
                        // ---- do nothing
                    }
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_DOWN)
                        || vk.getVirtualKeyId().equals(IVirtualKey.VKID_RIGHT)) {

                    CWidgetEvent ev = new CWidgetEvent(EVENT_CODE_SCROLL_DOWN);
                    if (!validatedDelegate.onProcessEvent(this, ev)) {
                        return CVirtualKey.VK_NONE;
                    }
                    
                    // ------ Move to next item
                    try {
                        if ((selectedListRow + 1) < getItems().size()) {
                            ++selectedListRow;
                            scrollMode = SCROLL_MODE_DOWN;
                        }
                        else if (circularNavigation) {
                            // Move back to the start of the list so the list is
                            // now circular
                            selectedListRow = 0;
                            scrollMode = SCROLL_MODE_DOWN;
                        }
                        fNeedRefresh = true;
                        vk = null;

                        stkidxTypeAheadMatches.clear();
                        strbufTypeAheadMatches.setLength(0);
                        selectItem(selectedListRow);
                    }
                    catch (IndexOutOfBoundsException ex) {
                        // ----- do nothing
                    }
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_TAB)) {
                    // Disabling event for tab.
                    fNeedRefresh = true;
                    vk = null;
                    stkidxTypeAheadMatches.clear();
                    strbufTypeAheadMatches.setLength(0);
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_HOME)) {

                    // ------ Move to first item
                    selectedListRow = 0;
                    fNeedRefresh = true;
                    vk = null;

                    stkidxTypeAheadMatches.clear();
                    strbufTypeAheadMatches.setLength(0);
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_END)) {

                    // ------ Move to last item
                    selectedListRow = getItems().size() - 1;
                    fNeedRefresh = true;
                    vk = null;

                    stkidxTypeAheadMatches.clear();
                    strbufTypeAheadMatches.setLength(0);
                }
                else if (vk.getVirtualKeyId().equals(IVirtualKey.VKID_ENTER)) {

                    // ------ Select current item
                    selectItem(selectedListRow);
                    fNeedRefresh = true;
                    /* If not selecting the previous item then
                     * set the value to 0.
                     */
                    scrollUpMode = 0;

                    selprovDelegate.fireSelectionEvent(this);
                    
                    // Execute onFieldExit actions before leaving the field
                    log.trace("<OnFieldExit Action> Executing for widget - "
                        + getIdentifier());

                    if (!validatedDelegate.onFieldExit(this)) {
                        vk = null;
                        continue;
                    }
                    else {
                        // refresh all to get changes from onFieldExit 
                        ((CForm) ((CDisplay) this.getDisplay())
                            .getCurrentFormOnStack())
                            .setRefreshRequired(true);

                        ((CDisplay) this.getDisplay())
                            .getCurrentFormOnStack().refresh();
                    }

                    // Check if the field is set to AutoAccept
                    // This is done at the end since any form code
                    // can at last minute set the current field to AutoAccept.
                    if (_fAutoAccept) {
                        vk = CVirtualKey.VK_EXIT_FORM;
                    }
                    else {
                        vk = CVirtualKey.VK_NEXT_FIELD;
                    }

                    stkidxTypeAheadMatches.clear();
                    strbufTypeAheadMatches.setLength(0);
                }
            }

            log.trace("TextSelection passing on "
                      + (vk != null? vk.getVirtualKeyId():"null"));
            
            tio.restoreCursor();
            return vk;
        }
        finally {
            ((CDisplay) getDisplay()).unlockTerminal();
        }
    }

    /**
     * Causes the text selection to lose focus, clear, and remove itself.
     */
    public void loseFocus() {
        super.loseFocus();
        
        clear();
        setVisible(false);
        IForm frm = getDisplay().getCurrentFormOnStack();
        
        // Let's refresh the form it's on. 
        frm.setRefreshRequired(true);
        frm.refresh();
    }
    
    /**
     * @inheritDoc
     * <p>
     * This method forwards the call to a
     * {@link CWidgetActionPerformedDelegate validated delegate}.
     * </p>
     */
    public void addWidgetAction(IWidgetActionValidator _validator)
            throws XInvalidArg, XInvalidRequest {
        validatedDelegate.addWidgetAction(_validator);
    }

    /**
     * <p>
     * This method forwards the call to a
     * {@link CWidgetActionPerformedDelegate validated delegate}.
     * </p>
     */
    public List<IWidgetActionValidator> getWidgetActions() {
        return validatedDelegate.getWidgetActions();
    }

    /**
     * <p>
     * This method forwards the call to a
     * {@link CWidgetActionPerformedDelegate validated delegate}.
     * </p>
     */
    public void removeValidator(IWidgetActionValidator _validator)
            throws XInvalidArg, XInvalidRequest {
        validatedDelegate.removeValidator(_validator);
    }

    public void addListener(ISelectionListener _listener) throws XInvalidArg {
        selprovDelegate.addListener(_listener);
    }

    public void removeListener(ISelectionListener _listener) {
        selprovDelegate.removeListener(_listener);
    }

    public boolean isAutoAccept() {
        return _fAutoAccept;
    }

    public void setAutoAccept(boolean fAutoAccept) {
        _fAutoAccept = fAutoAccept;
    }
    
    /**
     * Sets the select item in the text selection list if it has been defined
     * as the default variable record.
     */
    public void setVariableDefault() {
        
        // Sanity check for an early exit.
        if (getItems().isEmpty()) {
            return;
        }
        
        // IMPORTANT - PLEASE READ
        // Please note that the LOOKUP_FORM is the special kind of form that
        // that populates the text selection based on the setup on form and
        // field from which it is being invoked (i.e. previous form on stack).
        // Thus, we need to treat the lookup form as the special case where
        // will try to select an item on the list based on the value of the
        // field from which the lookup functionality is being invoked by F2 key.
        
        // Here are the possible scenarios:
        // ---------------------------------------------------------------------
        //    1. If this text selection widget is contained on the LOOKUP_FORM,
        //       then we want to try to select an item in the list based on the
        //       text value of entry field from which the lookup is being
        //       invoked if such value is not empty. I.e. this can be a value
        //       that the user has typed or simply a defined les_var_def
        //       configuration for that entry field.
        //    2. If the text value of the entry field from which the LOOKUP_FORM 
        //       is being invoked is empty, then we want to try to select the
        //       item in the list based on the defined variable default for
        //       that entry field (i.e. user may have deleted the text)
        //    3. Lastly, if this text selection is not on the LOOKUP_FORM, then
        //       we simply want to select an item in the list based on the
        //       var_nam (i.e. widget ID) of this text selection.
        
        CVarDef varDef = null;
        
        if (getBaseForm(this).getIdentifier().equals("LOOKUP_FORM")) {
            
            try {
                // Get the text value of the entry field from which the
                // LOOKUP_FORM is being invoked.
                String val = ((IEntryField) (this.getDisplay()
                 .getPreviousFormOnStack().getLowestFocusedWidget())).getText();
                
                if (val != null && !val.isEmpty()) {
                    // Based on the value of the entry field, select the
                    // item in the text selection list and exit.
                    selectByItemData(val);
                    return;
                }
                else {
                    // The text value of the entry field from which the lookup
                    // is being invoked is blank. Let's get the les_var_def
                    // configuration for that entry field so that we can
                    // select the appropriate item in the list.
                    varDef = ((ADataWidget) (this.getDisplay()
                        .getPreviousFormOnStack().getLowestFocusedWidget()))
                            .getVariableDefault();
                }
            }
            catch (MtfInterruptedException e) {
                // We need to re-throw this exception to make sure that it is
                // not trapped by the catch (Exception) below.
                throw e;
            }
            catch (Exception e) {
                log.error("An error occured while attempting to select an "
                    + "item in the text selection list.", e);
                return;
            }
        }
        else {
            // Get the les_var_def configuration for this text selection.
            varDef = getVariableDefault();
        }
        
        // Again, check for an early exit if variable default was not defined.
        if (varDef == null || !varDef.isEnaFlg()) {
            return;
        }
        
        // OK, now, let's attempt to select the item in the list based on the
        // defined variable default type and its value.
        
        switch (varDef.getDefType()) {
        
        case STRING:
            selectByItemData(varDef.getCharVal());
            break;
        case INTEGER:
            selectByItemData(Integer.toString(varDef.getIntVal()));
            break;
        case FLOAT:
            selectByItemData(Float.toString(varDef.getFltVal()));
            break;
        case DATETIME:
            try {
                // NOTE: due to the fact that we do not have an entry field
                // that is of date-time type, all we can do for now is to make
                // that we are using the internal RedPrairie presentation of
                // date-time value. Going forward, when the date-time data
                // type is implemented, we will need to take care of displayed
                // value on the terminal screen.
                DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
                String val = df.format(varDef.getDtVal());
                
                if (val != null && !val.isEmpty()) {
                    selectByItemData(val);
                }
            }
            catch (MtfInterruptedException e) {
                // We need to re-throw this exception to make sure that it is
                // not trapped by the catch (Exception) below.
                throw e;
            }
            catch (Exception e) {
                log.error("Unable to set the default datetime value.", e);
            }
            break;
        case COMMAND:
            try {
                MocaResults rs = null;
                
                // Pre-Process the command string to perform 
                // variable substitution.
                String command = "";
                command = preProcessCommandString(varDef.getDefCmd());
                rs = getDisplay().getSession().executeCommand(command);
                
                if (rs.next()) {
                    
                    // OK, let's first check whether a column with the same
                    // var_nam exists. If so, then use the value of that column
                    // to select the appropriate item in the text selection. 
                    // Otherwise, let's grab the value of the first column 
                    // to select an item in the text selection.
                    
                    String val = null;
                    
                    if (rs.containsColumn(this.getIdentifier())) {
                        val = rs.getString(this.getIdentifier());
                    }
                    else {
                        val = rs.getString(0);
                    }
                    
                    if (val != null && !val.isEmpty()) {
                        selectByItemData(val);
                    }
                }
            }
            catch (MocaException e) {
                log.error("Unable to set the default value for [" 
                    + this.getIdentifier() + "] "
                    + "widget after executing command.", e);
            }
            break;
        default:
            break;
        }
    }
    
    public int getItemLines() {
        return lines;
    }
    
    public void setItemLines(int itmLines) {
        this.lines = itmLines;
    }
    
    /**
     * Helper function to get the index for a value in any of ItemData fields
     * 
     * @param field
     * @param value
     * 
     * @return index
     */
    private int indexOfItemData(ItemDataField field, String value) {
        
        for (int i=0; i < getItems().size(); i++) {
            String strToCheck = "";
            
            switch (field) {
            case DISPLAY:
                strToCheck = ((ItemData) getItems().get(i)).getDisplay();
                break;
            case TRANSLATION:
                strToCheck = ((ItemData) getItems().get(i))
                    .getTranslatedDisplay();
                break;
            case VALUE:
                strToCheck = ((ItemData) getItems().get(i)).getValue();
                break;
            default:
                break;
            }
            
            // Check the controls value if is the correct index.
            if (strToCheck.equals(value)) {
                return i;
            }
        }
        
        // return -1 if not found
        return -1;
    }
    
    /**
     * {@link ItemData} is used to store the item number and display item number
     * for a particular item, so that we can switch between them if necessary,
     * without having to run a lookup on the database.
     * 
     * <b>
     * 
     * <pre>
     * Copyright (c) 2010 RedPrairie Corporation
     * All Rights Reserved
     * </pre>
     * 
     * </b>
     * 
     * @author jnazario
     * 
     * @version $Revision$
     */
    private final class ItemData {

        private String _itemDisplay;
        private String _itemTranslatedDisplay;
        private String _itemValue;

        /**
         * Constructor for ItemData
         * 
         * @param display
         * @param translation
         * @param value
         */
        private ItemData(String display, String translation, String value) {
            _itemDisplay = display;
            _itemTranslatedDisplay = translation;
            _itemValue = value;
        }

        /**
         * Get the Item number that will be displayed.
         * 
         * @return - displayed Item Number
         */
        public String getDisplay() {
            return _itemDisplay;
        }

        /**
         * Get the translated Item Number.
         * 
         * @return - translated Item Number
         */
        public String getTranslatedDisplay() {
            return _itemTranslatedDisplay;
        }

        /**
         * Get the base Item Number
         * 
         * @return base Item Number
         */
        public String getValue() {
            return _itemValue;
        }
    }
    
    private enum ItemDataField {DISPLAY, TRANSLATION, VALUE};
    
    /**
     * Selection padding width
     */
    private int cchSelectionPadding;

    /**
     * Selection provider delegate
     */
    private CSelectionProviderDelegate selprovDelegate;

    /**
     * Display prev/next markers
     */
    private boolean showMarkers;

    /**
     * Number of rows consumed by markers
     */
    private int markerRows;

    /**
     * Display parens around selected item
     */
    private boolean showSelection;

    /**
     * Display parens around selected item
     */
    private boolean circularNavigation;

    /**
     * Number of lines (rows) to use per occurrence
     */
    private int lines;

    /**
     * Auto-calculate Display Rows
     */
    private boolean autoRows;

    /**
     * Auto-calculate Display Columns
     */
    private boolean autoColumns;

    /**
     * Display columns
     */
    private int cchDisplayCols;

    /**
     * Display rows
     */
    private int cDisplayRows;

    /**
     * Selected index
     */
    private int idxSelected;
    
    /**
     * Display grid title
     */
    private boolean isDisplayGridTitle;

    /**
     * Compact display flag
     */
    private boolean fCompact;

    /**
     * Auto-accept flag
     */
    private boolean _fAutoAccept;

    /**
     * List of items in the control
     */
    private LinkedList<ItemData> _lstCtlItems;

    /**
     * Busy sizing flag
     */
    private boolean _fIamSizing = false;

    /**
     * Fields to be returned when selecting an item
     */
    private LinkedList<String> retFields;
    
    private boolean isRTL = false;
    
    /**
     * Used to determine how to position the rows
     * on the screen based on the scroll direction
     */
    private int scrollMode;
    private int scrollUpMode;
    
    /**
     * Future: list of concatenated display fields 
     */
    private LinkedList<String> dspFields;
    
    private static final char CH_LEFT_BRACKET = '(';

    private static final char CH_RIGHT_BRACKET = ')';

    private static final char CH_LEFT_TYPEAHEAD_BRACKET = '[';

    private static final char CH_RIGHT_TYPEAHEAD_BRACKET = ']';

    private static final String STR_SEPERATOR = "-";

    private static final String STR_SEPERATOR_UP = "^";

    private static final String STR_SEPERATOR_DOWN = "v";

    private static String spacing = "  ";

    private static final Logger log = Logger.getLogger(CDDATextSelection.class);

    /**
     * Serialization version identifier
     */
    private static final long serialVersionUID = -7501684568150640750L;
    
    private static final int SCROLL_MODE_UP = 0;
    private static final int SCROLL_MODE_DOWN = 1;
    /**
     * currentDisplayTop is used to keep track of
     * top display value.
     */
    private int currentDisplayTop;

}
