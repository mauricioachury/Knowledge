package com.alx.les.dda;

import java.util.List;

import com.redprairie.moca.MocaException;
import com.redprairie.mtf.MtfConstants;
import com.redprairie.mtf.exceptions.XFailedRequest;
import com.redprairie.mtf.exceptions.XFormAlreadyOnStack;
import com.redprairie.mtf.exceptions.XInvalidArg;
import com.redprairie.mtf.exceptions.XInvalidRequest;
import com.redprairie.mtf.exceptions.XInvalidState;
import com.redprairie.mtf.exceptions.XMissingObject;
import com.redprairie.mtf.foundation.presentation.ACommand;
import com.redprairie.mtf.foundation.presentation.ICommand;
import com.redprairie.mtf.foundation.presentation.IContainer;
import com.redprairie.mtf.foundation.presentation.IDisplay;

public class DdaForm2017 extends DdaFormBase {

	private static final String DdaFormClass = "com.alx.les.dda.DdaForm2017";
    public ICommand _cmdFkeyBack;
	
    public DdaForm2017(IDisplay _display) throws Exception {
		super(_display);
	}

	/**
	 * Display and run the form 
	 */
	public void run() throws XInvalidState, XInvalidRequest, XInvalidArg, XFailedRequest, XFormAlreadyOnStack, MocaException {
	    frmMain.interact();
	}

	@Override
	public String getDdaFormClass() {
		return DdaFormClass;
	}


	@Override
	public ICommand getNewFkeyBackCommand() {
		return new FkeyBackCommand();
	}


	@Override
	public ICommand getNewFkeyActionCommand(String ddaAction, char fkIdx, String fkCaption
			, List<String> actionFlds) {
		return new FkeyAction(ddaAction,fkIdx,fkCaption,actionFlds);
	}
	
	
    public class FkeyBackCommand extends ACommand {

        public FkeyBackCommand() {
            super("cmdFkeyBack", "FkeyBack",  MtfConstants.FKEY_BACK_CAPTION, '1');
        }

        public void execute(IContainer _container) throws  XFormAlreadyOnStack, NullPointerException, ClassNotFoundException, XInvalidState, XInvalidRequest, XInvalidArg, XFailedRequest, MocaException, XMissingObject {
			try {
				getDdaActionFactory().FkeyBack_Execute(_container);
			}
			// !! - MATCH NEW MTF SIGNATURE...
			catch (XFormAlreadyOnStack ex) {
				throw ex;
			}
			catch (NullPointerException ex) {
				throw ex;
			}
			catch (ClassNotFoundException ex) {
				throw ex;
			}
			catch (XInvalidState ex) {
				throw ex;
			}
			catch (XInvalidRequest ex) {
				throw ex;
			}
			catch (XInvalidArg ex) {
				throw ex;
			}
			catch (XFailedRequest ex) {
				throw ex;
			}
			catch (MocaException ex) {
				throw ex;
			}
			catch (XMissingObject ex) {
				throw ex;
			}
			catch (Exception ex) {
				ex.printStackTrace();
				MocaException mocaex = new MocaException(99999, "ERROR: FkeyBack.Execute"); 
				throw mocaex;
			}
        }
        
        private static final long serialVersionUID = 0L;
    }


	
	public class FkeyAction extends ACommand {
	
		private static final long serialVersionUID = 0L;
		private String _ddaId = "";
		private List<String> _actionFields;
		
        public FkeyAction(String ddaAction, char fkIdx, String fkCaption
        			, List<String> actionFlds) {
            super("cmdFkey"+ddaAction, "Fkey"+ddaAction
            		, fkCaption, fkIdx);
        	setDdaId(ddaAction);
        	setActionFields(actionFlds);
        }

        public String getDdaId() {
			return _ddaId;
		}
		private void setDdaId(String _ddaId) {
			this._ddaId = _ddaId;
		}
		public List<String> getActionFields() {
			return _actionFields;
		}
		private void setActionFields(List<String> actionFields) {
			this._actionFields = actionFields;
		}

		public void execute(IContainer _container) throws  XFormAlreadyOnStack, NullPointerException, ClassNotFoundException, XInvalidState, XInvalidRequest, XInvalidArg, XFailedRequest, MocaException, XMissingObject  {
			try {
				getDdaActionFactory().FkeyAction_Execute(_container, getDdaId(), getActionFields());
			}
			// !! - MATCH NEW MTF SIGNATURE...
			catch (XFormAlreadyOnStack ex) {
				throw ex;
			}
			catch (NullPointerException ex) {
				throw ex;
			}
			catch (ClassNotFoundException ex) {
				throw ex;
			}
			catch (XInvalidState ex) {
				throw ex;
			}
			catch (XInvalidRequest ex) {
				throw ex;
			}
			catch (XInvalidArg ex) {
				throw ex;
			}
			catch (XFailedRequest ex) {
				throw ex;
			}
			catch (MocaException ex) {
				throw ex;
			}
			catch (XMissingObject ex) {
				throw ex;
			}
			catch (Exception ex) {
				ex.printStackTrace();
				MocaException mocaex = new MocaException(99999, "ERROR: FkeyBack.Execute"); 
				throw mocaex;
			}
		}
	}
	

	
}
