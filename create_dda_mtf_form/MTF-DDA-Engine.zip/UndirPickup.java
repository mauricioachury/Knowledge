/*
 *  $URL$
 *  $Revision$
 *  $Author$
 *  $Date$
 *  
 *  $Copyright-Start$
 *
 *  Copyright (c) 2009
 *  RedPrairie Corporation
 *  All Rights Reserved
 *
 *  This software is furnished under a corporate license for use on a
 *  single computer system and can be copied (with inclusion of the
 *  above copyright) only for use on such a system.
 *
 *  The information in this document is subject to change without notice
 *  and should not be construed as a commitment by RedPrairie Corporation.
 *
 *  RedPrairie Corporation assumes no responsibility for the use of the
 *  software described in this document on equipment which has not been
 *  supplied or approved by RedPrairie Corporation.
 *
 *  $Copyright-End$
 */

package com.alx.les.dda;

import com.redprairie.mtf.MtfConstants;
import com.redprairie.wmd.WMDErrors;
import com.redprairie.wmd.WMDConstants;
import com.redprairie.moca.MocaException;
import com.redprairie.moca.MocaResults;
import com.redprairie.mtf.exceptions.XFailedRequest;
import com.redprairie.mtf.exceptions.XFormAlreadyOnStack;
import com.redprairie.mtf.exceptions.XInvalidArg;
import com.redprairie.mtf.exceptions.XInvalidRequest;
import com.redprairie.mtf.exceptions.XInvalidState;
import com.redprairie.mtf.foundation.presentation.ACommand;
import com.redprairie.mtf.foundation.presentation.AFormLogic;
import com.redprairie.mtf.foundation.presentation.CWidgetActionAdapter;
import com.redprairie.mtf.foundation.presentation.ICommand;
import com.redprairie.mtf.foundation.presentation.IContainer;
import com.redprairie.mtf.foundation.presentation.IDisplay;
import com.redprairie.mtf.foundation.presentation.IEntryField;
import com.redprairie.mtf.foundation.presentation.IForm;
import com.redprairie.mtf.foundation.presentation.IFormSegment;
import com.redprairie.mtf.foundation.presentation.IInteractiveWidget;
import com.redprairie.mtf.foundation.presentation.IWidgetActionValidator;


/**
 * This class is responsible for creating the CForm and adding
 * actions, commands, and timer events to handle the form's
 * processing actions.
 * <br>
 * <br>
 * This form is attached to the <em>RF Picking Menu > Pick Product</em> menu
 * item (undirected product pickup). The form accepts a work reference as input.
 * The work reference is validated and, if successful, launches the pickup A
 * form. The work reference scanned in this form will be the basis for the
 * pickup performed in pickup A.
 *  
 * <b>
 * 
 * <pre>
 * Copyright (c) 2009 RedPrairie Corporation
 * All Rights Reserved
 * </pre>
 * 
 * </b>
 * 
 * @author Nithin BN
 * @version Revision: $
 */

public class UndirPickup extends AFormLogic {

    // Instance Variables

    public IWidgetActionValidator    actUndirPickup;
    public IFormSegment              segDef;
    public IEntryField               efWrkref;
    public IWidgetActionValidator    actWrkref;

    public ICommand                  cmdFkeyBack;
    public ICommand                  cmdFkeyDone;

    // constants

    public UndirPickup(IDisplay _display) throws Exception {

        super(_display);

        // Create form and default segment

        frmMain = display.createForm("UNDIR_PICKUP");
        actUndirPickup = this.new UndirPickupActions();
        frmMain.addWidgetAction(actUndirPickup);

        segDef = frmMain.createSegment("segDef", false);

        // Create widgets on the form
        frmMain.setTitle("ttlUndirPickup");

        efWrkref = segDef.createEntryField("wrkref", "wrkrefLabel");
        efWrkref.setEnabled(true);
        efWrkref.setVisible(true);
        efWrkref.setEntryRequired(true);
        actWrkref = this.new WrkrefActions();
        efWrkref.addWidgetAction(actWrkref);

        // Create and bind function keys

        frmMain.unbind(frmMain.getCancelCommand());
        frmMain.unbind(frmMain.getNextNumberCommand());
        cmdFkeyBack = this.new FkeyBackCommand();
        cmdFkeyBack.setVisible(false);
        frmMain.bind(cmdFkeyBack);
        cmdFkeyBack.bind(MtfConstants.VK_FKEY_BACK);
        
        cmdFkeyDone = this.new FkeyDoneCommand();
        cmdFkeyDone.setVisible(false);
        frmMain.bind(cmdFkeyDone);
        cmdFkeyDone.bind(WMDConstants.VK_FKEY_DONE);
    }

    /**
     * Display and run the form 
     * @throws XFormAlreadyOnStack 
     * @throws XFailedRequest 
     * @throws XInvalidArg 
     * @throws XInvalidRequest 
     * @throws XInvalidState 
     */
    public void run() throws XInvalidState, XInvalidRequest, XInvalidArg, XFailedRequest, XFormAlreadyOnStack {

        frmMain.interact();
    }

    /**
     * Defines extended ACommand for FkeyBack 
     */
    private class FkeyBackCommand extends ACommand {

        /**
         * Prime constructor.
         */
        public FkeyBackCommand() {
            super("cmdFkeyBack", "FkeyBack",  MtfConstants.FKEY_BACK_CAPTION, '1');
        }

        /**
         * Performs the actions for the function key.
         *
         * @param _container
         *           Container
         * @throws XFormAlreadyOnStack 
         */
        public void execute(IContainer _container) throws XFormAlreadyOnStack {
            efWrkref.clear();
            frmMain.formBack();
        }

        private static final long serialVersionUID = 0L;
    }

    /**
     * Defines extended ACommand for FkeyDone 
     */
    private class FkeyDoneCommand extends ACommand {

        /**
         * Prime constructor.
         */
        public FkeyDoneCommand() {
            super("cmdFkeyDone", "FkeyDone", WMDConstants.FKEY_DONE_CAPTION, '6');
        }

        /**
         * Performs the actions for the function key.
         *
         * @param _container
         *           Container
         * @throws XFormAlreadyOnStack 
         * @throws ClassNotFoundException 
         * @throws NullPointerException 
         * @throws MocaException 
         * @throws XFailedRequest 
         * @throws XInvalidArg 
         * @throws XInvalidRequest 
         * @throws XInvalidState 
         */
        public void execute(IContainer _container) throws NullPointerException, ClassNotFoundException, XFormAlreadyOnStack, XInvalidState, XInvalidRequest, XInvalidArg, XFailedRequest, MocaException {
            AFormLogic     newFrm     = null;
            efWrkref.clear();
            display.setVariable("INIT_POLICIES.prvfrm", "UNDIR_PICKUP");
            display.setVariable("LOAD_SPLIT_DISPLAY.InitialRun", MtfConstants.RF_FLAG_TRUE);
            display.setVariable("LOAD_SPLIT_DISPLAY.prvfrm", "UNDIR_PICKUP");
            newFrm = display.createFormLogic("LOAD_SPLIT_DISPLAY");
            newFrm.run();
        }
        
        private static final long serialVersionUID = 0L;
    }
    
    /**
     * This class contains the entry/exit actions for the efWrkref field 
     */
    private class WrkrefActions extends CWidgetActionAdapter {

        public boolean onFieldExit(IInteractiveWidget _ef) throws Exception {
            MocaResults    rs         = null;
            int            retStatus  = WMDErrors.eOK;

            try {
                // They could have entered a pick identifier other than the
                // work reference#, e.g. subucc# or loducc#. If this is the
                // case, call GET TRANSLATED PICK IDENTIFIER to get wrkref#.
                // If it fails, return the message.
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL("get translated pick identifier " +
                                         "    where inpval = '" + efWrkref.getText() + "'" +
                                         "      and wh_id  = '" + display.getVariable("global.wh_id") + "'");
                rs.next();
                efWrkref.setText(rs.getString("actref"));
            }
            catch (MocaException e) {
                retStatus = e.getErrorCode();
                display.beep();
                if (retStatus == WMDErrors.eDB_NO_ROWS_AFFECTED) {
                    frmMain.promptMessageAnyKey(WMDConstants.MSG_INV_WORK);
                }
                else {
                    frmMain.displayErrorMessage();
                }
                efWrkref.clear();
                return false;
            }
            rs = null;
            
            /* Check whether the wrkref belongs to Asset Pick List. 
             * If it belongs, then we cannot continue with picking here.
             * Return an error saying that this wrkref belongs to 
             * Asset Pick List.
             */
            try {
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL(" [select 'X'" +
                                         "   from pcklst," +
                                         "        pckwrk_hdr"  +
                                         "  where pcklst.list_id = pckwrk_hdr.list_id " +
                                         "    and pcklst.asset_typ is not null " +
                                         "    and pckwrk_hdr.list_id is not null" + 
                                         "    and pckwrk_hdr.wrkref = '" + efWrkref.getText() + "'" +
                                         "    and pckwrk_hdr.wh_id = '" + display.getVariable("global.wh_id") + "']");
            }
            catch (MocaException e) {
                retStatus = e.getErrorCode();
                display.beep();
                if (retStatus != WMDErrors.eDB_NO_ROWS_AFFECTED) {
                    frmMain.displayErrorMessage();
                    return false;
                }
            }
            if (retStatus == WMDErrors.eOK)
            {
                frmMain.promptMessageAnyKey(WMDConstants.ERR_WRKREF_BELONGS_ASSET_LIST);
                return false;
            }    
            rs = null;
            
            /* Check whether the wrkref belongs to a List. 
             * If so then we cannot continue with picking here.
             * Return an error saying that this wrkref belongs to a list.
             */
            try {
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL(
                                          "[select 'X'" 
                                        + "   from pckwrk_hdr "  
                                        + "  where pckwrk_hdr.list_id is not null"  
                                        + "    and pckwrk_hdr.wrkref = '" 
                                        + efWrkref.getText() + "'" 
                                        + "    and pckwrk_hdr.wh_id = '" 
                                        + display.getVariable("global.wh_id")  
                                        + "']");
                
                if (rs != null && retStatus == WMDErrors.eOK) {
                    display.beep();
                    frmMain.promptMessageAnyKey(WMDConstants.ERR_WRKREF_BELONGS_LIST);
                    efWrkref.clear();
                    return false;
                }
            }
            catch (MocaException e) {
                retStatus = e.getErrorCode();
                display.beep();
                if (retStatus != WMDErrors.eDB_NO_ROWS_AFFECTED) {
                    frmMain.displayErrorMessage();
                    return false;
                }
            }
            rs = null;
            
            // This validation is specifically done to give error if entered
            // work is not yet released.
            try {
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL("validate rf wrkref " +
                                         "    where wrkref = '" + efWrkref.getText() + "'" +
                                         "      and devcod = '" + display.getVariable("global.devcod") + "'" +
                                         "      and wh_id = '" + display.getVariable("global.wh_id") + "'");

                // If the quantity to pick (pckqty) is 0, then this work 
                // reference is already picked.
                rs.next();
                if (rs.getInt("pckqty") <=0 ) {
                    display.beep();
                    frmMain.promptMessageAnyKey(WMDConstants.MSG_WRKREF_PICKED);
                    efWrkref.clear();
                    return false;
                }
            }
            catch (MocaException e) {
                retStatus = e.getErrorCode();
                display.beep();
                if (retStatus == WMDErrors.eDB_NO_ROWS_AFFECTED) {
                    frmMain.promptMessageAnyKey(WMDConstants.MSG_INV_WORK);
                }
                else {
                    frmMain.displayErrorMessage();
                }
                efWrkref.clear();
                return false;
            }
            // Should not allow Wrkref with Kit pick.
            rs = null;
            try {
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL(
                        "[select p1.wrkref "
                      + "   from pckwrk_view p1 "
                      + "  where p1.wrkref = '"
                      +      efWrkref.getText() + "'"
                      + "    and (( p1.ctnnum is not null ) "
                      + "           or (p1.wrktyp = '"
                      + WMDConstants.WRKTYP_KIT + "' "
                      + "              and exists(select 'x' "
                      + "                           from pckwrk_view p2 "
                      + "                          where p2.ctnnum = p1.subnum "
                      + "                            and p2.wrktyp = '"
                      + WMDConstants.WRKTYP_PICK + "')))] ");

                if (rs != null && retStatus == WMDErrors.eOK) {
                    display.beep();
                    frmMain.promptMessageAnyKey(WMDConstants.MSG_CANNOT_SCAN_KIT_PICK);
                    efWrkref.clear();
                    return false;
                }
            }
            catch (MocaException e) {
                  // Ignore.
            }
            rs = null;

            // Check if the pick is a multiple pick
            try {
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL("[select 'x' " +
                                         "   from pckwrk_view " +
                                         "  where wrkref = '" + efWrkref.getText() + "'" +
                                         "    and list_conf_flg = 1 " +
                                         "    and bto_dlv_seq is not null]");
                frmMain.promptMessageAnyKey(WMDConstants.MSG_MULT_PICK);
            }
            catch (MocaException e) {
                retStatus = e.getErrorCode();
                if (retStatus != WMDErrors.eDB_NO_ROWS_AFFECTED) {
                    display.beep();
                    frmMain.displayErrorMessage();
                    return false;
                }
            }
            rs = null;

            // Check if the user is authorized for the client
            try {
                retStatus = WMDErrors.eOK;
                rs = session.executeDSQL("[select client_id " +
                                         "   from pckwrk_hdr " +
                                         "  where wrkref = '" + efWrkref.getText() + "']" +
                                         "|" +
                                         "validate client for user " +
                                         "    where client_id = @client_id " +
                                         "      and wh_id     = '" + display.getVariable("global.wh_id") + "'" +
                                         "      and usr_id    = '" + display.getVariable("global.usr_id") + "'");
            }
            catch (MocaException e) {
                // Client authorization for user failed, display message and
                // re-enter the field
                retStatus = e.getErrorCode();
                display.beep();
                frmMain.displayErrorMessage();
                efWrkref.clear();
                return false;
            }
            rs = null;

            if (display.getVariable("global.directed_mode").equals(MtfConstants.RF_FLAG_NO))
            {
                // then check if the user is allowed to perform the work
                try {
                    retStatus = WMDErrors.eOK;
                    rs = session.executeDSQL(
                        "process work for carrier move assignments "+
                        "    where wrkref = '" + efWrkref.getText() + "'" +
                        "      and wh_id = '" + display.getVariable("global.wh_id") + "'"+
                        "      and usr_id ='" + display.getVariable("global.usr_id") + "'");
                }
                catch (MocaException e) {
                    display.beep();
                    frmMain.displayErrorMessage(e);
                    return false;
                }
            }
            
            // All validations passed
            return true;
        }
    }

    /**
     * This class contains the entry/exit actions for the form (frmMain) 
     */
    private class UndirPickupActions extends CWidgetActionAdapter {

        public boolean onFormEntry(IForm _frm) throws Exception {
            
            if (efWrkref.getLength() > 0)
            {
                int            retStatus  = WMDErrors.eOK;
                try {
                    retStatus = WMDErrors.eOK;
                    session.executeDSQL("[select 'x' from pckwrk_hdr "+                        
                                            "   where wrkref = '" + efWrkref.getText() + "'" +
                                            "     and appqty < pckqty " +
                                            "     and appqty <> 0 " +  
                                            "     and thresh_pck_flg = 1 ]");
                }
                catch (MocaException e) {
                    retStatus = e.getErrorCode();
                    if (e.getErrorCode() != WMDErrors.eDB_NO_ROWS_AFFECTED) {
                        display.beep();
                        frmMain.displayErrorMessage(e);
                        return false;
                    }
                }
                if (retStatus == WMDErrors.eOK)
                {
                    AFormLogic     newFrm     = null;
                    
                    display.setVariable("INIT_POLICIES.prvfrm", "UNDIR_PICKUP");
                    newFrm = display.createFormLogic("PICKUP_A");
                    newFrm.run();
                    return false;
                }
            }
            if (!display.getVariable("global.dda_mode").equals("1")) {
                efWrkref.clear();
            }
            return true;
        }

        public boolean onFormExit(IForm _frm) throws Exception {
            try {
                session.executeDSQL("[select 'x' from pckwrk_hdr "+                        
                                        "   where wrkref = '" + efWrkref.getText() + "'" +
                                        "     and appqty < pckqty]");
            }
            catch (MocaException e) {
                if (display.getVariable("global.dda_mode").equals("1")) {
                    
                    try {
                        session.executeDSQL("[select 'x' from inventory_view "+                        
                                                "   where stoloc =  @@devcod]");
                    }
                    catch (MocaException e1) {
                        AFormLogic     newFrm     = null;
                        String ddaForm = display.getVariable("global.dda_prvfrm");
                        newFrm = display.createFormLogic(ddaForm);
                        newFrm.run();
                    }
                    
                    AFormLogic     newFrm     = null;
                    display.setVariable(
                            "INIT_POLICIES.prvfrm", "UNDIR_PICKUP");
                    newFrm = display.createFormLogic("DEPOSIT_A");
                    newFrm.run();
                }
            }
            AFormLogic     newFrm     = null;
            display.setVariable("INIT_POLICIES.prvfrm", "UNDIR_PICKUP");
            newFrm = display.createFormLogic("PICKUP_A");
            newFrm.run();
            return false;
        }
    }
}
