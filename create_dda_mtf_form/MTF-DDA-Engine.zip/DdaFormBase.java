/* Copyright (C) Ascension Logistics - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Author ----  
 *      By Jonathan Nazario 
 *   Email <jnazario@ascensionlogistics.com>
 *    Date March 2017
 */
package com.alx.les.dda;


import java.util.Iterator;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.redprairie.mtf.foundation.presentation.AFormLogic;
import com.redprairie.mtf.foundation.presentation.IDisplay;
import com.redprairie.mtf.foundation.presentation.IForm;


public abstract class DdaFormBase extends DdaFactory {

    public static final String version = "2018.0.0.0";
    
    // Logger utility
    private static final Logger log = Logger.getLogger(DdaFormBase.class);

    protected boolean isFormLoaded = false;

    /**
     * IMPORTANT!!! ---------------
     * DDA Form construction is delayed until the object calls getForm().
     * Currently at this point we don't know what form we are loading
     * so we can only set generic properties here.
     */
    public DdaFormBase(IDisplay _display) throws Exception {

        super(_display);
        
    }
    
    /**
     * IMPORTANT!!! ---------------
     * This change is how we "hack" into the form construction.
     * getForm() is "the real form constructor".  Here is where we
     * find the form to load and get the necessary information
     * to dynamically add controls to the form.
     */
    @Override
    public IForm getForm() {
        
        if (!isFormLoaded)
        {
            String frmName = "UNKNOWN";
            String usrId = "";
            
            log.info("MTF-DDA: Is this a DDA? Trying to load...");
            
            // In order to find the FormName we are loading....
            // We need to get the map of <Form,Class> that are loaded
            // and find there the pointer to "this" object.
            // Once we have a match, we know the form name and 
            // loading the DDA can start.
            Iterator<Entry<String, AFormLogic>> it 
                    = display.getInstantiatedForms().entrySet().iterator();
            while (it.hasNext())
            {
                Entry<String, AFormLogic> pair = it.next();
                if ((AFormLogic) pair.getValue() == this)
                {    
                    // LOOK!! - I found myself in the stack...
                    // 
                    // Set it to loaded quick to avoid 
                    // recursive calls to getForm()
                    isFormLoaded = true;

                    // -- FORM NAME
                    frmName = (String)pair.getKey();
                    usrId = display.getVariable("global.usr_id");

                    log.info("MTF-DDA: Found! - Loading: " + frmName);

                    this.loadDda(frmName, usrId); 
                }
            }
            
            // Done Loading - return control to MTF...
            log.info("MTF-DDA: Loading Complete! - Form: " + frmName);
        }
        
        return super.getForm();
    }

// TODO: DECRYPT KEY...
//    public static String decrypt(String key, String initVector, String encrypted) {
//        try {
//            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
//            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
//
//            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
//            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
//
//            byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));
//
//            return new String(original);
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//
//        return null;
//    }

    
}
