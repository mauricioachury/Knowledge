package com.jda.mad.graphs;

public enum ChartType {
    JVM,
    MOCA,
    JOBS,
    TASKS,
    WS,
    INTEGRATOR,
    WM,
    OTHER;
}
