This mods is developped for validating the expiration date user scanned falls into the [min, max] range which defined by aging profile name, like '30/180' which means the expiration date scanned must be in 30 days to 180 days from now.

This is developped for version 2017.1